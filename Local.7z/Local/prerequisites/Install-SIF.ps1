#Sitecore Install Framework dependencies
Import-Module WebAdministration

 &"$PSscriptRoot\Install-Module.ps1" -moduleName "SitecoreInstallFramework" -version 2.1.0