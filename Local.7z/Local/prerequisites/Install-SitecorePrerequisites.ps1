$Global:ProgressPreference = 'SilentlyContinue'
Install-SitecoreConfiguration -Path (Resolve-Path (join-path $PSScriptRoot '.\prerequisites.json'))
$Global:ProgressPreference = 'Continue'