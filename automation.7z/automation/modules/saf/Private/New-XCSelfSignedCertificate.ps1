<#
.SYNOPSIS

#>
Function New-XCSelfSignedCertificate {
  [CmdletBinding(SupportsShouldProcess = $true)]
  Param(
    [Parameter(Mandatory=$true)]
    [String]
    $DnsName,

    [Parameter(Mandatory=$true)]
    [String]
    $DestinationFolderPath,

    [Parameter(Mandatory=$true)]
    [SecureString]
    $certPassword
  )


  [string] $thumbprint = (New-SelfSignedCertificate -DnsName $dnsName -Subject "CN=$dnsName @ Sitecore, Inc." -Type SSLServerAuthentication -FriendlyName "$dnsName Certificate").Thumbprint

  if (!(Test-Path -Path $DestinationFolderPath)) {
    Write-Verbose "The $DestinationFolderPath path is missing ..."

    if ($PSCmdlet.ShouldProcess("Creating $DestinationFolderPath location")) {
      New-Item -Path $DestinationFolderPath -ItemType Directory
    }
  }


  if ($PSCmdlet.ShouldProcess("Creating $thumbprint.pfx certificate file.")) {
    $certificateFilePath = Join-Path $DestinationFolderPath "$thumbprint.pfx"

    $certFile = Export-PfxCertificate -cert cert:\LocalMachine\MY\$thumbprint -FilePath "$certificateFilePath" -Password $certPassword
  }

  return $certFile
}