#Requires -Module Az.Accounts, Az.KeyVault

<#
.SYNOPSIS
Gets the XConnect certificate from the Key Vault and writes out the pfx to the destination folder using Thumbprint name.

#>
function Get-XCCertificate {
  [CmdletBinding()]
  Param(
    [Parameter(Mandatory = $true)]
    [String]
    $VaultName,

    [Parameter(Mandatory = $true)]
    [String]
    $CertificateName,

    [Parameter(Mandatory = $true)]
    [String]
    $Password,

    [Parameter(Mandatory = $true)]
    [ValidateScript( { Test-Path $_ })]
    [String]
    $DestinationFolderPath
  )

  $cert = Get-AzKeyVaultCertificate -VaultName $VaultName -Name $CertificateName
  $thumbprint = $cert.Thumbprint

  $secret = Get-AzKeyVaultSecret -VaultName $VaultName -Name $CertificateName

  $secretValueText = Get-SecretValueText -SecretValue $secret.SecretValue
  $secretByte = [Convert]::FromBase64String($secretValueText)
   
  $certCollection = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
  $certCollection.Import($secretByte, $null, [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable)
  $type = [System.Security.Cryptography.X509Certificates.X509ContentType]::Pfx
  $protectedCertificateBytes = $certCollection.Export($type, $Password)

  # Write to a file
  $certFilePath = Join-Path $DestinationFolderPath "$thumbprint.pfx"
  [System.IO.File]::WriteAllBytes($certFilePath, $protectedCertificateBytes)

  return $certFilePath
}