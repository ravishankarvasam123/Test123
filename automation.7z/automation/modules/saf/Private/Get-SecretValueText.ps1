
<#
.SYNOPSYS
Gets the seceret text value from the key vault.

#>
Function Get-SecretValueText {
  param(
      [Parameter(Mandatory=$true)]
      [ValidateNotNullOrEmpty()]
      [Security.SecureString] $SecretValue  
  )
  $ssPtr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secretValue)
try {
   $secretValueText = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ssPtr)
} finally {
   [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ssPtr)
}

return $secretValueText
}
