Function CheckMd5 {
  param(
      [string] $localFilePath,
      [string] $remoteBlobPath,
      $container,
      $context
  )
  $localMD5 = Get-MD5Hash -localPath $localFilePath # Get-FileHash -Path $localFilePath -Algorithm MD5
  Write-Host "Local File has Value:" $localMD5
  try {
    
      $blob = Get-AzStorageBlob -Blob $remoteBlobPath -Container $container -Context $context -ErrorAction Stop
      $cloudMD5 = $blob.ICloudBlob.Properties.ContentMD5
      Write-Host "Cloud hash file value:" $cloudMD5
  }
  catch {
      
      $cloudMd5 = $null
  }
  if ($cloudMd5 -ne $localMD5) {
      return $false
  }
  else {
      return $true
  }
}

Function Convert-HashToByteArray {
  [CmdletBinding()]
  Param ( [Parameter(Mandatory = $True, ValueFromPipeline = $True)] [String] $String )
  $String -split '([A-F0-9]{2})' | foreach-object { if ($_) { [System.Convert]::ToByte($_, 16) } }
}

<#
.SYNOPSYS
Gets the MD5 Hash of the local file located under localPath parameter.

#>
Function Get-MD5Hash {
  Param (
      [Parameter(Mandatory = $true)][String]$localPath
  )


  If (Test-Path -Path $localPath) {
      try {
          # Create the hasher and get the content
          $hashFromFile = Get-FileHash -Path $localPath -Algorithm MD5
          $filehash_as_bytes = Convert-HashToByteArray($hashFromFile.Hash)
          $hash = [System.Convert]::ToBase64String($filehash_as_bytes)           
        
      }
      catch {
          $hash = $null
      }
  }
  Else {
      # File doesn't exist, can't calculate hash
      $hash = $null  
  }
 
  # Open $file as a stream
              
  # Return the Base64 encoded MD5 hash
  return $hash
}