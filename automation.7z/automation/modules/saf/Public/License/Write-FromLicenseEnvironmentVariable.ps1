<#
.SYNOPSIS
Decompresses and writes out binary content stored in $env:SITECORELICENSE file.

.PARAMETER FilePath
The destination file path for the license file.
#>

Set-StrictMode -Version 3.0

function Write-FromLicenseEnvironmentVariable {
  [CmdletBinding()]
  param (
    [Parameter(Mandatory=$true)]
    [string]
    [ValidateScript({ Test-Path (Split-Path -parent $_)})]
    $FilePath
  )

  try {
    $licenseByteArray = [System.Convert]::FromBase64String($env:SITECORELICENSE)
    $from = [System.IO.MemoryStream]::new($licenseByteArray)
    $compress = [System.IO.Compression.GZipStream]::new($from,[System.IO.Compression.CompressionMode]::Decompress)
    $to = [System.IO.MemoryStream]::new()
    $compress.CopyTo($to)
    [io.file]::WriteAllBytes($FilePath, $to.ToArray())
  }
  finally {
    if ($null -ne $to) {
      $to.close();
    }
    if ($null -ne $compress) {
      $compress.close();
    }
  }
}