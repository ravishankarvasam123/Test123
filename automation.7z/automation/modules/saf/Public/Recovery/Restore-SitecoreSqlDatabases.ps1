#Requires -Module Az.Sql

<#
.SYNOPSIS
  Restores the Sitecore Databases on $SourceServerName server to $TargetServerName

.DESCRIPTION
  Restores the recoverable databases on $SourceServerName server to $TargetServerName that do not belong to a failover group.

.PARAMETER SourceResourceGroup
  Resource Group of the source Sql Server

.PARAMETER TargetResourceGroup
  Resource Group of the target Sql Server

#>

function Restore-SitecoreSqlDatabases {
  [CmdletBinding(SupportsShouldProcess)]
  Param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string] $SourceResourceGroup,
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string] $SourceServerName,
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string] $TargetResourceGroup,
    [ValidateNotNullOrEmpty()]
    [string] $TargetServerName,
    [Parameter(Mandatory = $false)]
    [string[]] $AzureSqlDatabaseNames = @(),
    [Parameter(Mandatory = $false)]
    [string] $TargetDatabaseNameSuffix =""
  )

  Write-Verbose "Getting recoverable databases from $SourceServerName"

  [string[]] $excludedDatabases = @();

  $failoverGroup = Get-AzSqlDatabaseFailoverGroup -ServerName $SourceServerName -ResourceGroupName $SourceResourceGroup
  if ($null -ne $failoverGroup) {
    $excludedDatabases = $failoverGroup.DatabaseNames
    Write-Verbose "The following databases are in failover group: $($excludedDatabases -join ',')"
  }

  if ($AzureSqlDatabaseNames.Count -eq 0) {
    $databasesToRestore = Get-AzSqlDatabase -ResourceGroupName $SourceResourceGroup -ServerName $SourceServerName | ?{ -not ($excludedDatabases -contains $_.DatabaseName.ToLower() ) }
    $geoBackups = $databasesToRestore | %{ Get-AzSqlDatabaseGeoBackup -ResourceGroupName $SourceResourceGroup -Server $SourceServerName -DatabaseName $_.DatabaseName -ErrorAction SilentlyContinue }

    Write-Verbose "Obtained the following $($geoBackups.Count) backups."
    $geoBackups | %{ Write-Verbose $_.DatabaseName }
  }
  else {
    $geoBackups = $AzureSqlDatabaseNames | ForEach-Object { Get-AzSqlDatabaseGeoBackup -ResourceGroupName $SourceResourceGroup -Server $SourceServerName -DatabaseName $_ -ErrorAction SilentlyContinue }
  }

  $geoBackups | ForEach-Object {
     if($_.DatabaseName.IndexOf("sessions-db") -gt 0){
       continue
     }
    if ($PSCmdlet.ShouldProcess("$TargetServerName`\$($_.DatabaseName)", "Restore")) {
      Write-Host " Initiating the restore of $TargetServerName`\$($_.DatabaseName) "
      $targetDBName = $_.DatabaseName
      if (-not [string]::IsNullOrEmpty($TargetDatabaseNameSuffix)) {
            $targetDBName = "{0}-{1}" -f $targetDBName,$TargetDatabaseNameSuffix
       }
      Restore-AzSqlDatabase -AsJob -FromGeoBackup -ResourceGroupName $TargetResourceGroup -ServerName $TargetServerName -TargetDatabaseName $targetDBName -ResourceId $_.ResourceId

    }
  }

  # Pull for finished jobs
  Get-Job | Wait-Job

}