#Requires -Module Az.Sql

<#
.SYNOPSIS
  Rename  the Sitecore Databases from $SqlServer

.DESCRIPTION
  Rename DB from the provided SQL Server that do not belong to the failover group.

.PARAMETER ResourceGroup
  Resource Group of the Sql Server

.PARAMETER SQLServerName
  Sql Server which has failover group defined

.PARAMETER AzureSqlDatabaseNames
  Sql Server DBs that are to be removed
#>

function Rename-SitecoreSqlDatabases {
  [CmdletBinding(SupportsShouldProcess, ConfirmImpact='High')]
  Param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string] $ResourceGroup,
    [ValidateNotNullOrEmpty()]
    [string] $SQLServerName,
    [Parameter(Mandatory = $false)]
    [string[]] $AzureSqlDatabaseNames = @(),
    [Parameter(Mandatory = $false)]
    [string] $DatabaseSearchFilter = "*-db",
    [Parameter(Mandatory = $false)]
    [string] $TargetDatabaseNameSuffix = "bak"
  )

  Write-Verbose "Getting databases from $SQLServerName"

  [string[]] $excludedDatabases = @();

  $failoverGroup = Get-AzSqlDatabaseFailoverGroup -ServerName $SQLServerName -ResourceGroupName $ResourceGroup
  if ($null -ne $failoverGroup) {
    $excludedDatabases = $failoverGroup.DatabaseNames
    Write-Verbose "The following databases are in failover group: $($excludedDatabases -join ',')"
  }

  if ($AzureSqlDatabaseNames.Count -eq 0) {
    $databasesToRename = Get-AzSqlDatabase -ResourceGroupName $ResourceGroup -ServerName $SQLServerName -DatabaseName $DatabaseSearchFilter | ?{ (-not ($excludedDatabases -contains $_.DatabaseName.ToLower())) -and ($_.SkuName -ne "System")}

    Write-Verbose  "The following databases are to be removed :"
    $databasesToRename | ForEach-Object { Write-Host $_.DatabaseName}
  }
  else {
     $databasesToRename  = $AzureSqlDatabaseNames | ForEach-Object { Get-AzSqlDatabase -ResourceGroupName $ResourceGroup -Server $SQLServerName -DatabaseName $_ -ErrorAction SilentlyContinue }
  }

  $databasesToRename | ForEach-Object {
    if ($PSCmdlet.ShouldProcess("$SQLServerName`\$($_.DatabaseName)", "Rename")) {
      Write-Host " Renaming  $SQLServerName`\$($_.DatabaseName) "
      $newName = "$($_.DatabaseName)-$($TargetDatabaseNameSuffix)"
      if(($TargetDatabaseNameSuffix -eq "") -and ($DatabaseSearchFilter -eq "*-restore")){
        $newName = $_.DatabaseName -replace "-restore",""
      }
      Set-AzSqlDatabase -ResourceGroupName $ResourceGroup -ServerName $SQLServerName -DatabaseName $_.DatabaseName -NewName $newName
    }
  }

  # Pull for finished jobs
  Get-Job | Wait-Job

}