#Requires -Modules Az.Sql, Az.KeyVault

<#
.SYNOPSIS
  Imports the bacpac file stored in storage account into Azure SQL Server.

.DESCRIPTION
  Imports the bacpac file stored in storage account into Azure SQL Server.

 .PARAMETER StorageResourceGroupName
  Resource group containing the storage account where the bacpac file resides

 .PARAMETER StorageAccountName
  storage account where the bacpac file resides

.PARAMETER BacpacStorageUri
  URI of the bacpac file to be imported

.PARAMETER SubscriptionName
  Subscription where the SQL service resides

.PARAMETER SQLResourceGroup
  Refers to resource group name that contains the SQL Server

.PARAMETER SQLServerName
  Sql Server name where the bacpac has to be imported

.PARAMETER AzureSqlDatabaseName
  Sql Database that will be created on importing the bacpac file. This database should be non existing in the SQL server.

.PARAMETER KeyVaultName
  key vault that contains sql server login name and password secrets

.PARAMETER SqlServerAdministratorLoginKeySecret
  Sql server login name secret stored in the key vault

.PARAMETER SqlServerAdminPasswordSecretName
  Sql server password secret name stored in the key vault

.PARAMETER SqlServerDatabaseEdition
  Sql server database edition that indicates the pricing tier

.PARAMETER SqlServerDatabaseServiceObjectiveName
  Sql server database service objective name

.PARAMETER DatabaseMaxSizeBytes
  Specifies the maximum size for the newly imported database


.Example
  # First import the module
  Import-Module "./modules/saf/saf.psd1" -Force -PassThru

  # Then run the function to import Database
   Import-SitecoreSqlDatabase -StorageResourceGroupName "bh-dbt-nonprod-sitecore-admin-rg" `
  -StorageAccountName "bhdbtnonprdscdev" `
  -BacpacStorageUri "https://bhdbtnonprdscdev.blob.core.windows.net/dbbackup/bh-dbt-sbx-sc-master-db-copy-2020-09-24-18-42.bacpac" `
  -SubscriptionName "BHDBTNonProduction" `
  -SQLResourceGroup "bh-dbt-sbx-sitecore-platform-rg" `
  -SQLServerName "bh-dbt-sbx-sc-sql" `
  -AzureSqlDatabaseName "bh-dbt-sbx-sc-master-db-test" `
  -KeyVaultName "bh-dbt-nonprod-sc-kv" -SqlServerAdministratorLoginKeySecret "sbx-sql-server-login" `
  -SqlServerAdminPasswordSecretName "sbx-sql-server-password" -SqlServerDatabaseEdition "Standard" `
  -SqlServerDatabaseServiceObjectiveName "S1" `
  -DatabaseMaxSizeBytes "268435456000"

#>
function Import-SitecoreSqlDatabase {
  [CmdletBinding(SupportsShouldProcess)]
  Param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $StorageResourceGroupName,
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $StorageAccountName,
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $BacpacStorageUri,
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $SubscriptionName,
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string] $SQLResourceGroup,
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string] $SQLServerName,
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string] $AzureSqlDatabaseName,
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $KeyVaultName,
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $SqlServerAdministratorLoginKeySecret,
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $SqlServerAdminPasswordSecretName,
    [Parameter(Mandatory = $true)]
    [ValidateSet("Free", "Basic", "Standard", "Premium" , "GeneralPurpose")]
    [String] $SqlServerDatabaseEdition,
    [Parameter(Mandatory = $true)]
    [ValidateSet("Free", "Basic", "S0", "S1", "S2", "S3", "S4", "S6", "S7", "S9", "S12", "P1", "P2", "P4", "P6", "P11", "P15", "GP_S_Gen5_1", "GP_Gen5_2", "GP_S_Gen5_2", "GP_Gen5_4", "GP_S_Gen5_4")]
    [String] $SqlServerDatabaseServiceObjectiveName,
    [ValidateNotNullOrEmpty()]
    [Long] $DatabaseMaxSizeBytes = 268435456000
  )

  $azContext = Get-AzContext

  if ($null -eq $azContext) {

    # Connect to Azure
    Connect-AzAccount
  }

  #set the context to right Subscription
  Set-AzContext -Subscription $SubscriptionName
  $azContext = Get-AzContext
  Import-Module -Name "Az.KeyVault"
  Import-Module -Name "Az.Sql"
  
  # Verify if the database already exists. If yes, then throw Error
  $AzSqlDatabase = Get-AzSqlDatabase -ResourceGroupName $SQLResourceGroup -ServerName $SQLServerName  -DatabaseName $AzureSqlDatabaseName -ErrorAction SilentlyContinue

  if ($null -ne $AzSqlDatabase) {
    $AzDatabaseName = "$AzureSqlDatabaseName-bak"
    Write-Host "Database $AzureSqlDatabaseName already exists in $SQLServerName server, Renaming it to $AzDatabaseName from $AzureSqlDatabaseName before import operation begins."
       
    Set-AzSqlDatabase -ResourceGroupName $SQLResourceGroup -ServerName $SQLServerName -DatabaseName $AzureSqlDatabaseName -NewName $AzDatabaseName
    Start-Sleep -s 20
  }

  # Get SAS Token token generated
  $saContext = (Get-AzStorageAccount -Name $StorageAccountName -ResourceGroupName $StorageResourceGroupName).Context
  $templateLinkAccessToken = New-AzStorageAccountSASToken -Context $saContext -Protocol HttpsOnly `
    -Service Blob -ResourceType Service, Container, Object -Permission rl -ExpiryTime ([DateTime]::Now.AddHours(3))
  if ($null -eq $templateLinkAccessToken) {
    Write-Host "Error in generating storage account shared access signature"  -ForegroundColor Red
    return
  }


  # Get keyvault secrets

  # Fetch Sql Login name from keyvault
  $sqlServerAdminLoginSecret = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name $SqlServerAdministratorLoginKeySecret -ErrorAction SilentlyContinue

  if ( $null -ne $sqlServerAdminLoginSecret) {
    $sqlServerAdminLogin = ConvertFrom-SecureString -SecureString $sqlServerAdminLoginSecret.SecretValue -AsPlainText
  }
  else {

    Write-Host "Retrieving key valut secret $SqlServerAdministratorLoginKeySecret failed.Terminating execution ..."  -ForegroundColor Red
    return
  }

  # Fetch Sql Login password from keyvault
  $sqlServerAdminPasswordSecret = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name $SqlServerAdminPasswordSecretName -ErrorAction SilentlyContinue

  if ( $null -ne $sqlServerAdminPasswordSecret) {
    $secureSqlServerAdminPassword = $sqlServerAdminPasswordSecret.SecretValue
  }
  else {
    Write-Host "Retrieving key valut secret $SqlServerAdminPasswordSecretName failed.Terminating execution ..."  -ForegroundColor Red
    return
  }

  if ($PSCmdlet.ShouldProcess("$SQLServerName`\$AzureSqlDatabaseName", "Import")) {

    $importRequest = New-AzSqlDatabaseImport -ResourceGroupName $SQLResourceGroup -ServerName $SQLServerName -DatabaseName $AzureSqlDatabaseName `
      -StorageKeyType "SharedAccessKey" -StorageKey $templateLinkAccessToken `
      -StorageUri $BacpacStorageUri `
      -AuthenticationType "Sql" `
      -AdministratorLogin $sqlServerAdminLogin -AdministratorLoginPassword $secureSqlServerAdminPassword -Edition $SqlServerDatabaseEdition `
      -ServiceObjectiveName $SqlServerDatabaseServiceObjectiveName `
      -DatabaseMaxSizeBytes $DatabaseMaxSizeBytes

    Write-Host "Import operation has been started for database $AzureSqlDatabaseName"  -foregroundcolor White

    $importStatus = Get-AzSqlDatabaseImportExportStatus -OperationStatusLink  $importRequest.OperationStatusLink
    
    ## Check database import operation status in every 30 seconds until it gets failed/succeeded
    while ("InProgress" -ieq $importStatus.Status) {
      Start-Sleep -s 30      
      $importStatus = Get-AzSqlDatabaseImportExportStatus -OperationStatusLink $importRequest.OperationStatusLink -ErrorAction SilentlyContinue
    }

    if ("Failed" -ieq $importStatus.Status ) {
      Write-Host "Database import operation failed for database $AzureSqlDatabaseName" -ForegroundColor Red
    }
    elseif ("Succeeded" -ieq $importStatus.Status) {
      Write-Host "Database import operation completed successfully for database $AzureSqlDatabaseName" -foregroundcolor Green
    }
  }
}