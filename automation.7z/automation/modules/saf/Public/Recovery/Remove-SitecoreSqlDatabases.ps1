#Requires -Module Az.Sql

<#
.SYNOPSIS
  Removes  the Sitecore Databases from $SqlServer

.DESCRIPTION
  Remove DB from the provided SQL Server that do not belong to the failover group.

.PARAMETER ResourceGroup
  Resource Group of the Sql Server

.PARAMETER SQLServerName
  Sql Server which has failover group defined

.PARAMETER AzureSqlDatabaseNames
  Sql Server DBs that are to be removed
#>

function Remove-SitecoreSqlDatabases {
  [CmdletBinding(SupportsShouldProcess, ConfirmImpact='High')]
  Param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string] $ResourceGroup,
    [ValidateNotNullOrEmpty()]
    [string] $SQLServerName,
    [Parameter(Mandatory = $false)]
    [string[]] $AzureSqlDatabaseNames = @()
  )

  Write-Verbose "Getting databases from $SQLServerName"

  [string[]] $excludedDatabases = @();

  $failoverGroup = Get-AzSqlDatabaseFailoverGroup -ServerName $SQLServerName -ResourceGroupName $ResourceGroup
  if ($null -ne $failoverGroup) {
    $excludedDatabases = $failoverGroup.DatabaseNames
    Write-Verbose "The following databases are in failover group: $($excludedDatabases -join ',')"
  }

  if ($AzureSqlDatabaseNames.Count -eq 0) {
    $databasesToRemove = Get-AzSqlDatabase -ResourceGroupName $ResourceGroup -ServerName $SQLServerName | ?{ -not ($excludedDatabases -contains $_.DatabaseName.ToLower() ) }

    Write-Verbose  "The following databases are to be removed :"
    $databasesToRemove | ForEach-Object { Write-Host $_.DatabaseName}
  }
  else {
     $databasesToRemove  = $AzureSqlDatabaseNames
  }

  $databasesToRemove | ForEach-Object {
    if ($PSCmdlet.ShouldProcess("$SQLServerName`\$($_.DatabaseName)", "Remove")) {
      Write-Host " Deleting $SQLServerName`\$($_.DatabaseName) "
      if($_.SkuName -ne "System"){
      Remove-AzSqlDatabase -ResourceGroupName $ResourceGroup -ServerName $SQLServerName -DatabaseName $_.DatabaseName
      }
    }
  }

  # Pull for finished jobs
  Get-Job | Wait-Job

}