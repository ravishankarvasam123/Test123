function Test-ServerAccess([string] $ip, [int] $statusCode, [string] $rgName, [string] $cmWebAppName, [switch]$DebugSecurity, [string]$url)
{
      [int]$count = 0
      [double]$sleepToTestServerAccess = 3
      # continue checking for 30 seconds if status code equals to 403
      while($statusCode -eq 403 -and $count -lt 10)
      {
          $count++
          Write-Host "Trying for $count"
          Write-Host "Status Code: $statusCode"
          Write-Verbose "Forbidden error occurred"
          # Start sleep for 3 seconds
          Start-Sleep -Seconds $sleepToTestServerAccess

          if($DebugSecurity)
          {
             Write-Host "Below is list of all access rules present in app service"
             Write-Host (Get-AzWebAppAccessRestrictionConfig -ResourceGroupName $rgName -Name $cmWebAppName).MainSiteAccessRestrictions.IpAddress
          }
          # check if it is present in access rule         
          
          [bool]$isPresent = (Get-AzWebAppAccessRestrictionConfig -ResourceGroupName $rgName -Name $cmWebAppName).MainSiteAccessRestrictions.IpAddress -contains "$ip/24"
          Write-Verbose "Access Rule is Present or not: $isPresent"
          $statusCode = Get-UrlStatusCode -Url $url
      }
      return $statusCode
}