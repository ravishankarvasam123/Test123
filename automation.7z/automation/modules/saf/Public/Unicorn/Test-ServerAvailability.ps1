function Test-ServerAvailability {  
  Param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string] $challengeURL,
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string] $statusCode
  )
        [int]$serverUnavailabilityCount = 0
        [double]$sleepToTestServerAvailability = 15
        # induce sleep of 15 seconds and wait for maximum of 2 minutes for the site to load
        while($statusCode -eq 503 -and $serverUnavailabilityCount -lt 8)
        {
          $serverUnavailabilityCount++
          Write-Verbose "Server is unavailable, status code is: $statusCode, checking for count $serverUnavailabilityCount"
          #Sleep for 15 Seconds
          Start-Sleep -Seconds $sleepToTestServerAvailability
          $statusCode  = Get-UrlStatusCode -Url $challengeURL
        }
        return $statusCode
  }