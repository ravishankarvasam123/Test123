Function Modify-UnicornSecret {
  param(
      [System.Security.SecureString] $Secret,
      [string] $UnicornConfigPath
      )
      $XPath = "configuration/sitecore/unicorn/authenticationProvider/SharedSecret"
      $xml = [xml](Get-Content -Path $UnicornConfigPath)
      $element = $xml.SelectSingleNode($XPath)
      $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secret)
      $secretValue = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
      $element.InnerText = $secretValue
      $xml.Save($UnicornConfigPath)
}