
<#
.SYNOPSIS
  Processes json files

.DESCRIPTION
  Converts <repo-root>/configuration/<envConfig>/InstallConfiguration.json, asset.json files.

.PARAMETER ConfigurationFile
  A path to InstallConfiguration.json file which is located under ./infra/configuration/<environment>/InstallConfiguration.json

.EXAMPLE
$configArray = ProcessConfigFile -Config $ConfigurationFilePath
$config = $configArray[0]
$assetconfig = $configArray[1]
$azureconfig = $configArray[2]
$azureconfigFile = $configArray[3]
$templatesPath = $configArray[4]
#>
function ProcessConfigFile {
  [CmdLetBinding()]
  Param (
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [Alias ("Config")]
    [string] $ConfigurationFile
  )

  Write-Host "Process Configuration File: $ConfigurationFile"
  ####################################
    # Find and process installConfiguration.json
    ####################################
  if (!(Test-Path $ConfigurationFile))
  {
    Write-Host  "Configuration file '$($ConfigurationFile)' not found." -ForegroundColor Red
    Write-Host  "Please ensure there is a cake-config.json configuration file at '$($ConfigurationFile)'" -ForegroundColor Red
    Exit 1
  } else {
    Write-Verbose "Configuration file '$($ConfigurationFile)' is detected."
  }
  Write-Host "Processing Completed of Configuration File: $ConfigurationFile"
  $config = Get-Content -Raw $ConfigurationFile | ConvertFrom-Json



  if (!$config) {
    throw "Error trying to load configuration!"
  }

  Write-Host "Script that started me: $($MyInvocation.PSCommandPath)"

  $rootProjectPath = $config.ProjectRoot
   Write-Host "rootProjectPath: $rootProjectPath"

  $parentPath = Split-Path -parent $MyInvocation.PSCommandPath
  Write-Host "Parent Path: $parentPath"

  $rootPath =  join-path $rootProjectPath "/infra"
  Write-Host "RootPath: $rootPath"

  $templatesPath = $(join-path $rootPath  ("templates/{0}-{1}-{2}" -f $config.Hosting, $config.Version, $config.topology))
  Write-Host "Templates Path: $templatesPath"

  $configurationFileFolderPath = split-path -Parent $ConfigurationFile
  Write-Host "Configuration File Folder Path: $configurationFileFolderPath"

  $config | Add-Member -Name ConfigurationFolderPath -Value (Resolve-Path $configurationFileFolderPath) -MemberType NoteProperty
  Write-Host "Config $config"

  Write-Host "Templates Path: $templatesPath"
  Write-Host "Configuration File Folder Path: $configurationFileFolderPath"

  if (-not [System.IO.Path]::IsPathRooted($config.DeployFolder)) {
    $config.DeployFolder = join-path $rootProjectPath $config.DeployFolder
  }


  ###############################
  # Find and process assets.json
  ###############################

  [string] $assetsConfigFile = $([io.path]::Combine($templatesPath, 'assets.json'))
  Write-Host "Process Assest Json File: $assetsConfigFile"
  if (!(Test-Path $assetsConfigFile))
  {
    Write-Host "Assets file '$($assetsConfigFile)' not found." -ForegroundColor Red
    Write-Host  "Please ensure there is a assets.json file at '$($assetsConfigFile)'" -ForegroundColor Red
    Exit 1
  }
  Write-Host "Processing Completed Assest Json File: $assetsConfigFile"

  $assetconfig = Get-Content -Raw $assetsConfigFile |  ConvertFrom-Json
  Write-Host "Process Assest Config File: $assetconfig"

  if (!$assetconfig)
  {
    throw "Error trying to load Assest File!"
  }

  #########################################
  # Find and process azureuser-config.json
  #########################################

  [string] $azureconfigFile = $([io.path]::combine($configurationFileFolderPath, 'azure-config.json'))
  Write-Host "Process Azure Config File: $azureconfigFile"

  if (!(Test-Path $azureconfigFile))
  {
    Write-Host "azureuser-config file '$($azureconfigFile)' not found." -ForegroundColor Red
    Write-Host  "Please ensure there is a azure-config.json configuration file at '$($azureconfigFile)'" -ForegroundColor Red
    Exit 1
  }

  $azureconfig = Get-Content -Raw $azureconfigFile |  ConvertFrom-Json
  Write-Host "Process Azure Config: $azureconfigFile"
  if (!$azureconfig)
  {
    throw "Error trying to load azureuser-config.json!"
  }

  return $config, $assetconfig, $azureconfig, $azureconfigFile, $templatesPath
}