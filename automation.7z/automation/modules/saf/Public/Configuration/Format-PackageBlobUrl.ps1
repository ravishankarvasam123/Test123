<#
.SYNOPSIS
Formats the Blob Url for the Sitecore Web Deploy package.

.PARAMETER PackageBaseName
package File Name
.PARAMETER StorageAccountName
A Storage account name where blob is located
.PARAMETER TemplateBasePath
A base path in the storage account where the blob of the package is located.
.PARAMETER TemplateAccessToken
A Template Access Token (SAS signature) which grants access to the package.
.PARAMETER GenerateNoDatabaseNameFragment
Injects "nodatabase" into the package name fragment to designate that DACPAC actions are removed.

#>

Set-StrictMode -Version 3.0

function Format-PackageBlobUrl {
  [CmdletBinding()]
  param (
    # PackageBaseName
    [Parameter(Mandatory=$true)]
    [string]
    $PackageBaseName,
    # Storage Account Name where Package is located
    [Parameter(Mandatory=$true)]
    [string]
    $StorageAccountName,
    # Template base path
    [Parameter(Mandatory = $true)]
    [string]
    $TemplateBasePath,
    # Parameter help description
    [Parameter(Mandatory=$true)]
    [string]
    $TemplateAccessToken,
    [Parameter(Mandatory=$false)]
    [switch]
    $GenerateNoDatabaseNameFragment
  )
  if($GenerateNoDatabaseNameFragment -and (-not $PackageBaseName.Contains('withoutdb'))) {
    $PackageBaseName = $packageBaseName.Substring(0, $packageBaseName.LastIndexOf(".scwdp.zip")) + ".withoutdb.scwdp.zip"
  }

  return "https://{0}.blob.core.windows.net/{1}/{2}{3}" -f $StorageAccountName, $TemplateBasePath, $PackageBaseName, $TemplateAccessToken
}