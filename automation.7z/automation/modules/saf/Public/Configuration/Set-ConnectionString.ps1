<#
.SYNOPSIS
 Set the connection string in the app config

.DESCRIPTION
  Converts <repo-root>/XDTs/App_Config/ConnectionStrings.config.xdt

.PARAMETER filePath
  A path to the config file which is located under ./infra/configuration/<environment>/XDTs/App_Config/ConnectionStrings.config.xdt

.PARAMETER connectionstringName
    key to the connection string

.PARAMETER connectionString
    connection string value

.EXAMPLE
Set-ConnectionString -filePath $filePath -connectionStringName $connectionStringName -connectionString $connectionString 
#>

Function Set-ConnectionString{
	[CmdletBinding(SupportsShouldProcess=$True)]
	Param(
        [string]$filePath,
        [string]$connectionStringName,
        [System.Security.SecureString]$connectionString
    )
	
	$config = [xml](Get-Content -Path $filePath)
	#get the connection strings
    $config.connectionStrings
    #Select the node
    $connStringElement = $config.SelectSingleNode("connectionStrings/add[@name='$connectionStringName']")
    #if the node exist
    if($connStringElement) {
        $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($connectionString)
        $secretValue = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
        #Set the connection string value
        $connStringElement.connectionString = $secretValue
    	Write-Host ("Updating ConnectionStrings.config connection string {0} to be {1}" -f $connectionStringName, $connectionString)
        $config.Save($filePath)
    	
    }
    else{
        Write-Error "Unable to locate connection string named: $connectionStringName"
    }
}