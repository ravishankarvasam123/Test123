<#
.SYNOPSYS
Ensures that XConnect Certificates are locally obtained and available for deployment

#>
function Create-XCCertificate {
  [CmdLetBinding()]
  Param (
    [parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [Alias ("Config")]
    [string] $ConfigurationFile
  )


  if ([string]::IsNullOrEmpty($ConfigurationFile)) {

    throw "Configuration File is requires ...."
  }

  $configArray = ProcessConfigFile -Config $ConfigurationFile
  $config = $configArray[0]
  $assetconfig = $configArray[1]
  $azureconfig = $configArray[2]
  $azureconfigFile = $configArray[3]
  $templatesPath = $configArray[4]

  $dnsNameSetting = $azureconfig.settings | Where-Object { $_.id -eq "DnsName" }
  $dnsName = $dnsNameSetting.value
  $keyVaultName = ($azureconfig.settings | Where-Object {$_.id -eq "KeyVaultName"}).value
  $certificateName = ($azureconfig.settings | Where-Object {$_.id -eq "CertificateName" }).value


  # Fetch certificate file path
  $certificatePath = (Join-Path $config.DeployFolder "assets")
  $certificateFullPath = ($azureconfig.settings | Where-Object {$_.id -eq "XConnectCertfilePath" }).value

  # Fetch XConnect certificate Password
 $connectCertSetting = ($azureconfig.settings | Where-Object {$_.id -eq "XConnectCertificatePassword" })
 if($connectCertSetting){
 $secret = $connectCertSetting.value
 }
 if(-not [string]::IsNullOrEmpty($env:XCONNECTCERTIFICATEPASSWORD)){
   $secret =$env:XCONNECTCERTIFICATEPASSWORD
  }

  # Get/ create the XConnect certificate if the certificate path is missing
  if ([string]::IsNullOrEmpty($certificateFullPath)){
          $certPassword = ConvertTo-SecureString -String $secret -Force -AsPlainText
            $cert = ''
            Write-Verbose "Getting Certificate ...."

            if(-not ([string]::IsNullOrEmpty($keyVaultName))) {
              $cert = Get-XCCertificate -VaultName $keyVaultName -CertificateName $certificateName -Password $secret -DestinationFolderPath $certificatePath
              # Get-XCertificate returns full Certificate Path
              $certificateFullPath = $cert
            }
            if ([string]::IsNullOrEmpty($cert)) {
              Write-Verbose "Creating Certificate ...."

              $cert = New-XCSelfSignedCertificate -DnsName $dnsName  -DestinationFolderPath $certificatePath -CertPassword $certPassword
              if($null -ne $cert) {
                if ($cert -is [array]) {
                  $certificateFullPath = $cert[-1].FullName
                }
                else {
                  $certificateFullPath = $cert.FullName
                }
              }
            }
  }

  foreach ($setting in $azureconfig.settings) {
    if ($setting.id -eq "XConnectCertfilePath") {
      $setting.value = $certificateFullPath
    }
  }

  $azureconfig | ConvertTo-Json | set-content $azureconfigFile

}