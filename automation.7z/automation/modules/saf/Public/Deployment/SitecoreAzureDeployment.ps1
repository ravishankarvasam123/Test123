

Function SitecoreAzureDeployment {
  [CmdletBinding(SupportsShouldProcess = $true)]
  param(
        [Parameter(Mandatory=$true)]
        [string] $ToolkitFolderPath,
        [parameter(Mandatory=$true)]
        [alias("Region")]
        [string]$Location,
        [parameter(Mandatory=$true)]
        [string]$Name,
        [parameter(ParameterSetName="Template URI", Mandatory=$true)]
        [string]$ArmTemplateUrl,
        [parameter(ParameterSetName="Template Path", Mandatory=$true)]
        [string]$ArmTemplatePath,
        [parameter(Mandatory=$true)]
        [string]$ArmParametersPath,
        [parameter(Mandatory=$true)]
        [string]$LicenseXmlPath,
        [hashtable]$SetKeyValue
    )

try {
        Write-Verbose "Tools Folder Path: $ToolkitFolderPath"
        if (Test-Path "$ToolkitFolderPath\Sitecore.Cloud.Cmdlets.dll") {
          Import-Module "$ToolkitFolderPath\Sitecore.Cloud.Cmdlets.dll"
        }
        else {
          throw "Failed to find Sitecore.Cloud.Cmdlets.dll, searched $PSScriptRoot and $PSScriptRoot\bin"
        }
        Write-Host "Deployment Started..."

        if ([string]::IsNullOrEmpty($ArmTemplateUrl) -and [string]::IsNullOrEmpty($ArmTemplatePath)) {
            Write-Host "Either ArmTemplateUrl or ArmTemplatePath is required!"
            Break
        }

        if(!($Name -cmatch '^(?!.*--)[a-z0-9]{2}(|([a-z0-9\-]{0,37})[a-z0-9])$'))
        {
            Write-Error "Name should only contain lowercase letters, digits or dashes,
                         dash cannot be used in the first two or final character,
                         it cannot contain consecutive dashes and is limited between 2 and 40 characters in length!"
            Break;
        }

        if ($SetKeyValue -eq $null) {
            $SetKeyValue = @{}
        }

        # Set the Parameters in Arm Template Parameters Json
        $paramJson = Get-Content $ArmParametersPath -Raw

        Write-Verbose "Setting ARM template parameters..."

        # Read and Set the license.xml
        $licenseXml = Get-Content $LicenseXmlPath -Raw -Encoding UTF8
        $SetKeyValue.Add("licenseXml", $licenseXml)

        # Update params and save to a temporary file
        $paramJsonFile = "temp_$([System.IO.Path]::GetRandomFileName())"
        Set-SCAzureDeployParameters -ParametersJson $paramJson -SetKeyValue $SetKeyValue | Set-Content $paramJsonFile -Encoding UTF8

        Write-Verbose "ARM template parameters are set!"

        # Deploy Sitecore in given Location
        Write-Verbose "Deploying Sitecore Instance..."
        $notPresent = Get-AzResourceGroup -Name $Name -ev notPresent -ea 0
        if (!$notPresent) {
            New-AzResourceGroup -Name $Name -Location $Location -Tag @{ "provider" = "b51535c2-ab3e-4a68-95f8-e2e3c9a19299" }
        }
        else {
            Write-Verbose "Resource Group Already Exists."
        }

        if ([string]::IsNullOrEmpty($ArmTemplateUrl)) {
            $PSResGrpDeployment = New-AzResourceGroupDeployment -Name $Name -ResourceGroupName $Name -TemplateFile $ArmTemplatePath -TemplateParameterFile $paramJsonFile
        }else{
            # Replace space character in the url, as it's not being replaced by the cmdlet itself
            $PSResGrpDeployment = New-AzResourceGroupDeployment -Name $Name -ResourceGroupName $Name -TemplateUri ($ArmTemplateUrl -replace ' ', '%20') -TemplateParameterFile $paramJsonFile
        }
        $PSResGrpDeployment
    }
    catch
    {
      Write-Host "Encountered error in Sitecore Azure Deployment"
      Write-Verbose $_.Exception

      throw;
    }
    finally {
      if (Test-Path $paramJsonFile) {
        Remove-Item $paramJsonFile
      }
    }
}