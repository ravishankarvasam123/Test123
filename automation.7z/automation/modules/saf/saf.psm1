set-StrictMode -Version 2.0
<#
.SYNOPSIS
Loads the module functions and exports the functions under ./public/** structure to be public.

#>

# Get Functions
$private = [array] (Get-ChildItem -Path (Join-Path $PSScriptRoot Private) -Include *.ps1 -File -Recurse)
$public = [array] (Get-ChildItem -Path (Join-Path $PSScriptRoot Public) -Include *.ps1 -File -Recurse)

# Dot source to scope
# Private must be sourced first - usage in public functions during load
($private + $public) | ForEach-Object {
  try {
    Write-Verbose "Loading script $($_.FullName) "
    . $_.FullName
  }
  catch {
      Write-Warning $_.Exception.Message
  }
}

$public | ForEach-Object {
  Export-ModuleMember $_.BaseName
}