# Sitecore Automation Framework

This module contains PowerShell cmdlets to manage Sitecore Azure environment.

## Installation

```powershell
Import-Module <Repository Root>\infrastructure\automation\Sitecore.Automation.Framework
```

## Usage

Much of the functionality of the module relies on the Azure Context to be available to the session.  Therefore, developer must make sure they login to azure and obtain context interactively during their debug sessions.

The module is purposefully designed to work in non-administrative mode to support execution within Azure Pipelines using hosted build agent.

### Login to Azure

To connect to Azure, use the [`Connect-AzAccount`] cmdlet:

```powershell
# Device Code login
Connect-AzAccount

# Service Principal login
Connect-AzAccount -ServicePrincipal -ApplicationId 'http://my-app' -Credential $PSCredential -TenantId $TenantId
```
