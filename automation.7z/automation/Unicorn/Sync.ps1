
param([string]$url, [string]$secret, [bool]$debug, [string]$rgName, [string]$cmWebAppName)

[bool]$checkifRulePresent = $false
try
{
  $ScriptPath = Split-Path $MyInvocation.MyCommand.Path
  Import-Module $(join-path (Split-Path -parent $ScriptPath) "\modules\saf\saf.psd1") -Force -PassThru

  Import-Module $ScriptPath\Unicorn.psm1
  [int]$countToCheckAccessRule = 0
  [bool]$isAccessRuleAdded = $false
  [string]$accessRuleName = "Azure Shell IP"
  [int]$ipRange = 32
  [int]$sleepTimeToCheckAcessRule = 3

  #check if old settings for access rule is left behind or not
  [bool]$oldAccessRuleIsPresent = (Get-AzWebAppAccessRestrictionConfig -ResourceGroupName $rgName -Name $cmWebAppName).MainSiteAccessRestrictions | ?{ $_.RuleName -eq $accessRuleName }

  if($oldAccessRuleIsPresent)
  {
      Remove-AzWebAppAccessRestrictionRule -ResourceGroupName $rgName -WebAppName $cmWebAppName -Name $accessRuleName
  }

  $ip = Invoke-RestMethod http://ipinfo.io/json | Select -exp ip

  # checking to see if it is running locally or ip is already present
  [bool]$isPresent = (Get-AzWebAppAccessRestrictionConfig -ResourceGroupName $rgName -Name $cmWebAppName).MainSiteAccessRestrictions.IpAddress -contains "$ip/32"
  Write-Verbose "Is Access Rule Already Present: $isPresent"  
  
  if(!$isPresent)
  {
    $accessRestrictionConfig = Add-AzWebAppAccessRestrictionRule -ResourceGroupName $rgName -WebAppName $cmWebAppName -Name $accessRuleName -Priority 100 -Action Allow -IpAddress $ip/$ipRange -PassThru      
    $isAccessRuleAdded = $accessRestrictionConfig.MainSiteAccessRestrictions.IpAddress -contains "$ip/$ipRange"
	  Write-Verbose "Is Access Rule Added: $isAccessRuleAdded"
    $checkifRulePresent = (Get-AzWebAppAccessRestrictionConfig -ResourceGroupName $rgName -Name $cmWebAppName).MainSiteAccessRestrictions.IpAddress -contains "$ip/$ipRange"
	  Write-Verbose "Is Access Rule Present: $checkifRulePresent"
    # retry if access rule is not reflecting or added for 30 seconds and in period of 3 seconds
    while(!$checkifRulePresent -and $countToCheckAccessRule -lt 10)
    {
			Write-Verbose "Rule is not added"
      Write-Verbose "Starting sleep to check for acces rule"
      Start-Sleep -Seconds $sleepTimeToCheckAcessRule
      $countToCheckAccessRule++
      $checkifRulePresent = (Get-AzWebAppAccessRestrictionConfig -ResourceGroupName $rgName -Name $cmWebAppName).MainSiteAccessRestrictions.IpAddress -contains "$ip/$ipRange"
			Write-Host "Checking if Rule is Present: $checkifRulePresent for $countToCheckAccessRule" 
    }

    if($countToCheckAccessRule -ge 10 -and !$checkifRulePresent)
    {
      Write-Verbose "Unable to add Access Rule"
      throw "Exception Occurred while adding Access Rule"
    }
  }

  [string]$challengeURL = "$($url)?verb=Challenge"
	[int]$statusCode  = Get-UrlStatusCode -Url $challengeURL
	Write-Verbose "Status code: $statusCode"

  # check for forbidden error or server unavailability
  [int]$countToCheckStatus = 0
  while(($statusCode -eq 403 -or $statusCode -eq 503) -and $countToCheckStatus -lt 2)
  {
    $countToCheckStatus++
    if($statusCode -eq 403)
    {
      Write-Verbose "Status code: $statusCode"
      $statusCode = Test-ServerAccess -ip $ip -statusCode $statusCode -rgName $rgName -cmWebAppName $cmWebAppName -DebugSecurity:$DebugSecurity -url $challengeURL
      Write-Host "After checking access rule final status code is: $statusCode"
    }
    elseif($statusCode -eq 503)
    {
      Write-Verbose "Status code: $statusCode"
      $statusCode = Test-ServerAvailability -challengeURL $challengeURL -statusCode $statusCode
    }          
  }
  if($statusCode -eq 200)
  {
    Write-Verbose "Status code: $statusCode"
    # SYNC ALL CONFIGURATIONS
    Sync-Unicorn -ControlPanelUrl $url -SharedSecret $secret -DebugSecurity:$debug
  }
  else
  {
    #if we are still not able to get 200 status there may be other error on the site and needs to be thrown
    Write-Verbose "Unable to browse site: $statusCode"
    throw "Error Occurred while accessing the server, current status code is - $statusCode"
  }
      
       


    # SYNC ALL CONFIGURATIONS
    # Sync-Unicorn -ControlPanelUrl $url -SharedSecret $secret -DebugSecurity:$debug

    # SYNC SPECIFIC CONFIGURATIONS
    # Sync-Unicorn -ControlPanelUrl 'https://localhost/unicorn.aspx' -SharedSecret 'your-sharedsecret-here' -Configurations @('Test1', 'Test2')

    # SYNC ALL CONFIGURATIONS, SKIPPING ANY WITH TRANSPARENT SYNC ON
    # Sync-Unicorn -ControlPanelUrl 'https://localhost/unicorn.aspx' -SharedSecret 'your-sharedsecret-here' -SkipTransparentConfigs

    # Note: you may pass -Verb 'Reserialize' for remote reserialize. Usually not needed though.
    # Note: If you are having authorization issues, add -DebugSecurity to your cmdlet invocation; this will display the raw signatures being used to compare to the server.

}
catch
{
  Write-Error -Message ("Exception Occurred while executing the sync task " + ": $($_.Exception)")
}
finally
{
  if($checkifRulePresent -or $isPresent)
  {
      Remove-AzWebAppAccessRestrictionRule -ResourceGroupName $rgName -WebAppName $cmWebAppName -Name "Azure Shell IP"
  }
}