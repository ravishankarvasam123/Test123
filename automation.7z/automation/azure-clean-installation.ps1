[CmdletBinding(SupportsShouldProcess=$true)]
Param(
  [Parameter(Mandatory=$true)]
  [string] $ConfigurationFilePath = $(join-path (Split-Path -parent $PSScriptRoot) "\configuration\sbx\install.json")
)

Write-Verbose "Script Execution Started"

#Import ProcessConfigFile function
Import-Module $PSScriptRoot\modules\saf\saf.psd1 -Force
$configArray = ProcessConfigFile -Config $ConfigurationFilePath
$azureconfig = $configArray[2]

## Get required settings for sitecore-azure deployment
$azurePrefixSetting = $azureconfig.settings | Where-Object { $_.id -eq "prefix" }
$azurePrefix = $azurePrefixSetting.value

## Get the environment
$azureEnvironmentSetting = $azureconfig.settings | Where-Object { $_.id -eq "environment" }
if ($null -ne $azureEnvironmentSetting) {
  $azureEnvironment = $azureEnvironmentSetting.value
}

Function RemoveResources {
    param(
        [string] $rg
        )
        $allResources = Get-AzResource -ResourceGroupName  $rg                                     
            if($allResources){   
              
              foreach ($r in $allResources){                      
                      try {                           
                            $msg = "-------------> Removing Resource: {0}-{1}" -f $r.Name, $r.ResourceId 
                            write-verbose $msg                        
                            Remove-AzResource -ResourceId $r.ResourceId -Force                
                   
                      }
                      catch {
                          $ErrorMessage = $_.Exception.Message      
                          Write-Verbose = $ErrorMessage    
                         
                      }
                      finally {                    
                      }   
              }        
          }
            #Get the remaining Resource Count
           $remainingResources = Get-AzResource -ResourceGroupName  $resourceGroupName
            $rCount = $remainingResources.Count 
          if($rCount -gt 0 ){
              $attempt = $attempt + 1
              Write-Verbose "Error Occured - Deleting the resource. Attempt: $attempt"
              RemoveResources -rg $rg
          }
      
          Write-Verbose "Pause the execution for 5 minute. Once the resource delete operation is completed"
          Start-Sleep -s 300
  }



    
#remove the existing resources
$resourceGroupName = "{0}-{1}-{2}" -f $azurePrefix, $azureEnvironment, "sitecore-platform-rg"
Write-Verbose "Resource Group Name: $resourceGroupName"
RemoveResources -rg $resourceGroupName
Write-Verbose "Script Execution Completed"