
    [CmdLetBinding()]
    Param (
      [parameter(Mandatory=$true)]
      [ValidateNotNullOrEmpty()]
      [Alias ("Config")]
      [string] $ConfigurationFile
    )


if([string]::IsNullOrEmpty($ConfigurationFile)){

     throw "Configuration File is required"
}

Push-Location

Set-Location $PSScriptRoot

Import-module $PSScriptRoot\modules\saf\saf.psd1

Create-XCCertificate -ConfigurationFile $ConfigurationFile

Pop-Location