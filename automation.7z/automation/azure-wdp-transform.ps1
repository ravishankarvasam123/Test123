[CmdletBinding(SupportsShouldProcess=$true)]
Param(
  [Parameter(Mandatory=$true)]
  [string] $CargoPayloadArtifacts = "sbx-cm-role",
  [Parameter(Mandatory=$true)]
  [string] $ConfigurationFilePath = $(join-path (Split-Path -parent $PSScriptRoot) "\configuration\sbx\install.json"),
  #C:\Repos\dbt-sitecore-platform\infra\configuration\dev\install.json
  [Parameter(Mandatory=$true)]
  [string] $scwdp = "Sitecore 9.2.0 rev. 002893 (Cloud)_cm.scwdp.zip",
  [Parameter(Mandatory=$false)]
  [System.Security.SecureString] $UnicornSecret
)

#Import ProcessConfigFile function
Import-Module $PSScriptRoot\modules\saf\saf.psd1 -Force
$configArray = ProcessConfigFile -Config $ConfigurationFilePath
$config = $configArray[0]
$azureconfig = $configArray[2]

#logic to get the generated sccpl file name
$scppl_filename = $CargoPayloadArtifacts + ".sccpl"
$CargoPayloadArtifacts = (Join-Path $config.ConfigurationFolderPath $CargoPayloadArtifacts) #$CargoPayloadArtifacts.Replace("/","\") #$ConfigurationFilePath = $ConfigurationFilePath.Replace("/","\")

#scppl file get created at the parent folder of $CargoPayloadArtifacts - get the parent folder
$packagePath = (Split-Path -parent $CargoPayloadArtifacts) # $CargoPayloadArtifacts.substring(0, $CargoPayloadArtifacts.LastIndexOf('\'))
# $packagepath = C:\SiteCore\dbt-sitecore-platform\infra\configuration\dev\dev-cm-role
# C:\SiteCore\dbt-sitecore-platform\infra\configuration\dev\dev-cm-role\CopyToWebsite\App_Config\dev

$unicornconfig =  Join-Path $CargoPayloadArtifacts "CopyToWebsite\App_Config\Environment\Serialization.Unicorn.Provider.config"
if ((Test-Path $unicornconfig) -and $UnicornSecret) {  
  Write-Verbose "Unicorn Config Exist"
  Modify-UnicornSecret -Secret $UnicornSecret -UnicornConfigPath $unicornconfig
  Write-Verbose "Successfully Updated Serialization.Unicorn.Provider.config"
}

$assetsFolder = (Join-Path $config.DeployFolder "assets")
$file_sccpl =  (Join-Path $packagePath $scppl_filename) 
#set the wdp path
$scwdp = (Join-Path $assetsFolder "Sitecore Experience Platform\$scwdp")
#import the functions to perform wdp update
Import-Module "$assetsFolder/Sitecore Azure Toolkit/tools/Sitecore.Cloud.Cmdlets.psm1"
Import-Module "$assetsFolder/Sitecore Azure Toolkit/tools/Sitecore.Cloud.CmdLets.dll"
if (Test-Path $file_sccpl) {  Remove-Item $file_sccpl -Force }

#region Sitemap

#download Sitemap-BH.xml file from Azure storage account to the CopyToWebsite folder of CargoPayload artifact

function Get-Sitemap {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $true)]
    [string]$SitemapFilename,
    [Parameter(Mandatory = $true)]
    [string] $DestinationFolder,
    [Parameter(Mandatory = $true)]
    [string] $StorageAccountName
  )

  try
  {
  #Get storage account Context
  $storageContext = New-AzStorageContext -StorageAccountName $StorageAccountName -UseConnectedAccount

  $sitemapContainerName = "sitemap"
  if ($null -ne $env:SitemapContainer) {
    $sitemapContainerName = $env:SitemapContainer
  }

  #Get the blob content and save it  in the destination folder
  Write-Host "Downloading Sitemap file from Azure blob storage $StorageAccountName"


  Get-AzStorageBlob -Container $sitemapContainerName -Blob $SitemapFilename -Context $storageContext -ErrorAction "Stop" `
  | Get-AzStorageBlobContent -Destination $DestinationFolder -AsJob -Force

  #wait for the download file jobs finish
  Get-Job | Wait-Job
  }
  Catch
  {
     $message = $_.Exception.message
     Write-Verbose "An error occured while downloading the file from blob $sitemapContainerName $message"
  }
}

#set the env:SiteMapFile "*" in case need to copy all the files
$sitemapFileName = "sitemap-BH.xml" 
if ($null -ne $env:SiteMapFile) {
  $sitemapFileName = $env:SiteMapFile
}
#Get the storage account name
$storageAccountNameSetting = $azureconfig.settings | Where-Object { $_.id -eq "StorageAccountName" }
$storageAccoutName = $storageAccountNameSetting.value

Write-Host "Storage Account name: $storageAccoutName"
Write-Host $(Join-Path $CargoPayloadArtifacts "CopyToWebsite\")

#update the payload for cd only
if ($CargoPayloadArtifacts.Contains('cd-role') )
{
  Get-Sitemap -SitemapFilename $sitemapFileName -DestinationFolder $(Join-Path $CargoPayloadArtifacts "CopyToWebsite\") -StorageAccountName $storageAccoutName
}
 #Stop-AzureRmResourceGroupDeployment -Name mynewstorageaccount -ResourceGroupName myrg
#endregion Sitemap 

Write-Verbose "Cargo Payload artifact: $CargoPayloadArtifacts"
Write-Verbose "Cargo Payload file path: $packagePath"
Write-Verbose "Sitecore wdp : $scwdp"

New-SCCargoPayload -Path $CargoPayloadArtifacts -Destination $packagePath -Verbose -Force
Update-SCWebDeployPackage -Path $scwdp -CargoPayloadPath (Resolve-Path $file_sccpl)

Write-Verbose "sitecore web deploy package updated successfully"