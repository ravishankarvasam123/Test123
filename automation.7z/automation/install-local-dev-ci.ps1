#Requires -RunAsAdministrator

[CmdletBinding(SupportsShouldProcess = $true)]
Param(
  [string] $modulePath = "Sitecore.Automation.Framework",
  [string] $Version = "1.2.0-alpha",
  [switch] $Reprovision = $false,
  [string] $packageSourcePath,
  [string] $SASToken
)

$ErrorActionPreference = "Stop"

$rootPath = Resolve-Path -Path "$PSScriptRoot/../../"
$packageSourcePath = Join-Path $rootPath "infra/packages/onprem-9.0.2-xp0"
$packagePath = Join-Path "$rootPath" "/build/deploy/packages/"
$packageName = "Sitecore 9.0.2 rev. 180604 (OnPrem)_single.withoutdb.scwdp.zip"

$SAT = Join-Path $rootPath "infra/SAT"

Import-Module $modulePath
Import-Module SitecoreInstallFramework

try {
  Push-Location "$rootPath/infra/configuration/local"
  # # Generate latest sccpl
  # npm run stage

  # Update the web deploy package

  Import-Module $SAT/tools/Sitecore.Cloud.Cmdlets.psm1
  Import-Module $SAT/tools/Sitecore.Cloud.Cmdlets.dll

  if (Join-Path $packageSourcePath $packageName) {
    copy (Join-Path $packageSourcePath $packageName) (Join-Path $packagePath $packageName) -Verbose:$VerbosePreference
    Update-SCWebDeployPackage -Path (Join-Path $packagePath $packageName) -CargoPayloadPath (Join-Path $rootPath ".\build\deploy\CargoPayloads\website.sccpl")
  }


  Write-Output "Deploying ..."

  $prefix = "BH"
  $clientCert = "$($Prefix)_SitecoreClient_SAF"
  $license = "$rootPath/build/assets/license.xml"
  $hostNames = ("hccm.bannerhealth.local", "www.bannerhealth.local")
  $siteName = "hccm.bannerhealth.local"
  $xConnectHostName = "xconnect.bannerhealth.local"
  $sqlServer = "."
  $sqlUser =  "sa"
  $sqlAdminPassword =  "S0g3tiR0cks!"
  $sqlSitecorePassword = "B@nn3rR0cks!"
  $installDir = "C:\inetpub\wwwroot\hccm.bannerhealth.local"
  $solrServiceURL = "https://solr.bannerhealth.local:8393/solr"
  $package =  Join-Path $packagePath $packageName
  $SAFInstallPackageDir = $packagePath

  if ($package) {

      if ($package.StartsWith("http") -and $SASToken) {
          $package
          Start-BitsTransfer -Source $package -Destination "$SAFInstallPackageDir/$packageName"
      }
  }


  # Templates
  $TemplatePath = Join-Path $rootPath "infra/templates/onprem-9.0.2-xp0/overrides/sitecore-xp0.json"

  $sitecoreParams = @{
    Path                           = "$TemplatePath"
    Package                        = $package
    LicenseFile                    = $license
    SqlDbPrefix                    = $prefix
    SqlServer                      = $sqlServer
    SqlAdminUser                   = $sqlUser
    SqlAdminPassword               = $sqlAdminPassword
    SqlCoreUser                    = "$($prefix)_coreuser"
    SqlCorePassword                = $sqlSitecorePassword
    SqlMasterUser                  = "$($prefix)_masteruser"
    SqlMasterPassword              = $sqlSitecorePassword
    SqlWebUser                     = "$($prefix)_webuser"
    SqlWebPassword                 = $sqlSitecorePassword
    SqlReportingUser               = "$($prefix)_reportinguser"
    SqlReportingPassword           = $sqlSitecorePassword
    SqlProcessingPoolsUser         = "$($prefix)_processingpoolsuser"
    SqlProcessingPoolsPassword     = $sqlSitecorePassword
    SqlProcessingTasksUser         = "$($prefix)_processingtasksuser"
    SqlProcessingTasksPassword     = $sqlSitecorePassword
    SqlReferenceDataUser           = "$($prefix)_referencedatauser"
    SqlReferenceDataPassword       = $sqlSitecorePassword
    SqlMarketingAutomationUser     = "$($prefix)_marketingautomationuser"
    SqlMarketingAutomationPassword = $sqlSitecorePassword
    SqlFormsUser                   = "$($prefix)_formsuser"
    SqlFormsPassword               = $sqlSitecorePassword
    SqlExmMasterUser               = "$($prefix)_exmmasteruser"
    SqlExmMasterPassword           = $sqlSitecorePassword
    SqlMessagingUser               = "$($prefix)_messaginguser"
    SqlMessagingPassword           = $sqlSitecorePassword
    SolrCorePrefix                 = $prefix
    SolrUrl                        = $solrServiceURL
    XConnectCert                   = $clientCert
    Sitename                       = $siteName
    XConnectCollectionService      = "https://$xConnectHostName"
    InstallDirectory               = $installDir
  }

  Install-SitecoreConfiguration  @sitecoreParams -Verbose:$VerbosePreference

  Pop-Location

  Write-Output "Deployment of Sitecore is done."

}
catch
{
}



function LoadCofigurations {
  [CmdletBinding()]
  Param
  (
      [string]$ConfigName
  )

  $dir = Get-Location
  $configFile = "$dir\$ConfigName.json"

  if (!(Test-Path $configFile)) {
      throw "Please, provide '$ConfigName.json' file."
  }

  $global:Configuration = Get-Content -Raw -Path $configFile | ConvertFrom-Json
}
