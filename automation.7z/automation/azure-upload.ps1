
[CmdletBinding()]
Param(
  [parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [String] $ConfigurationFilePath,
  [Switch] $SkipWdpPackageUpload,
  [Parameter(Mandatory=$false)]
  [ValidateSet("local","sbx","dev","qa","uat","prod")]
  [string] $DeploymentEnvironment
)

Import-Module "$PSScriptRoot/modules/saf/saf.psd1" -Force -PassThru

$configArray = ProcessConfigFile -Config $ConfigurationFilePath
$config = $configArray[0]
$assetconfig = $configArray[1]
$azureconfig = $configArray[2]
$azureconfigFile = $configArray[3]
$templatesPath = $configArray[4]


## Get Azure Configuration Settings
$subscriptionNameSetting = $azureconfig.settings | Where-Object { $_.id -eq "SubscriptionName" }
[string]$subscriptionName = $subscriptionNameSetting.value

$azureResourceGroupNameSetting = $azureconfig.settings | Where-Object { $_.id -eq "AzureAdminResourceGroup" }
[string]$resourceGroupName = $azureResourceGroupNameSetting.value

$regionSetting = $azureconfig.settings | Where-Object { $_.id -eq "AzureRegion" }
$region = $regionSetting.value

$storageAccountSettings = $azureconfig.settings | Where-Object { $_.id -eq "StorageAccountName" }
[string]$storageAccountName = $storageAccountSettings.value

$templateContainerSetting = $azureconfig.settings | Where-Object { $_.id -eq "TemplateContainerName" }
[string]$templateContainerName = $templateContainerSetting.value

$wdpPackageContainerSetting = $azureconfig.settings | Where-Object { $_.id -eq "WDPPackageContainerName" }
[string]$wdpPackageContainerName = $wdpPackageContainerSetting.value


Import-Module Az.Accounts
Import-Module Az.Resources

#Get the stage for Upload

#if the parameter DeploymentEnvironment is not null then set the environment  from the parameter
$azureEnvironmentSetting = $azureconfig.settings | Where-Object { $_.id -eq "environment" }
$script:azureEnvironment = $azureEnvironmentSetting.value
if(-not [string]::IsNullOrEmpty($DeploymentEnvironment))
{
  $script:azureEnvironment = $DeploymentEnvironment
}

#Step1: Connect to Azure using account credential - Interactive mode
$azContext = Get-AzContext

if ($nul -eq $azContext) {
  Write-Host "Connecting Azure"
  Write-Host "Subscription"  $subscriptionName
  Connect-AzAccount  -Subscription $subscriptionName
  $azContext = Get-AzContext
  $saContext = $null
}

try {

  "Verifying the existence of the Azure resource group.... " + $resourceGroupName
  $group = Get-AzResourceGroup -Name $resourceGroupName -ErrorAction Stop
}

catch {
  Write-Verbose "Encountered error when verifying existence of Azure Resour Group $resourceGroupName "
  Write-Verbose $_.Exception

  if ($null -eq $group) {
    "Trying to create the azure resource group..." + $resourceGroupName
    New-AzResourceGroup -Name $resourceGroupName -Location $region
  }
}

try {

  "Verifying the existence of the Azure storage account ...." + $storageAccountName
  $saContext = Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $resourceGroupName -ErrorAction Stop
}
catch {
  Write-Verbose "Encountered error when verifying existence of Azure Storage Account $storageAccountName"
  Write-Verbose $_.Exception

  if ($null -eq $saContext) {
    "Trying to create the azure storage account..." + $storageAccountName
    $saContext = New-AzStorageAccount -Name $storageAccountName -ResourceGroupName $resourceGroupName  -Location $region -Kind "StorageV2"  -SkuName "Standard_LRS"
  }
}

try {

  "Verifying the existence of the storage container...."+ $templateContainerName
  $templateContainer = Get-AzStorageContainer -Name $templateContainerName  -Context $saContext.Context -ErrorAction Stop
}
catch {
  if ($null -eq $templateContainer ) {
    "Trying to create the azure storage container..." + $templateContainerName
    New-AzStorageContainer -Name $templateContainerName  -Permission Off -Context $saContext.Context
  }
}

try {

  "Verifying the existence of the storage container...." + $wdpPackageContainerName
  $mediaContainer = Get-AzStorageContainer -Name $wdpPackageContainerName  -Context $saContext.Context  -ErrorAction Stop
}
catch {
  if ($null -eq $mediaContainer) {
    "Trying to create the azure storage container..." + $wdpPackageContainerName
    New-AzStorageContainer -Name $wdpPackageContainerName   -Permission Off -Context $saContext.Context
  }
}

###############

### Upload topology/templates to azure

###############

$blobPrefix = "$($script:azureEnvironment.ToLower())/$($config.Hosting.ToLower())/$($config.Version)/"

Push-Location $templatesPath
$regexTemplatePath = [regex]::Escape($templatesPath + "\")
Get-ChildItem -File -Recurse |ForEach-Object -Process{ $_ | Set-AzStorageBlobContent -Container $templateContainerName -Context $saContext.Context -Blob "$(($_.FullName -ireplace $regexTemplatePath,$blobPrefix).Replace("\","/"))" -Force }
Pop-Location

if ($SkipWdpPackageUpload) { return; }

###############

### Upload sitecore web deploy package to azure

###############

Function CheckMd5 {
  param(
    [string] $localFilePath,
    [string] $remoteBlobPath,
    $container,
    $context
  )
  $localMD5 = Get-MD5Hash -localPath $localFilePath # Get-FileHash -Path $localFilePath -Algorithm MD5
  Write-Host "Local File has Value:" $localMD5
  try {

    $blob = Get-AzStorageBlob -Blob $remoteBlobPath -Container $container -Context $context -ErrorAction Stop
    $cloudMD5 = $blob.ICloudBlob.Properties.ContentMD5
    Write-Host "Cloud hash file value:" $cloudMD5
  }
  catch {

    $cloudMd5 = $null
  }
  if ($cloudMd5 -ne $localMD5) {
    return $false
  }
  else {
    return $true
  }
}

Function Convert-HashToByteArray {
  [CmdletBinding()]
  Param ( [Parameter(Mandatory = $True, ValueFromPipeline = $True)] [String] $String )
  $String -split '([A-F0-9]{2})' | foreach-object { if ($_) { [System.Convert]::ToByte($_, 16) } }
}
Function Get-MD5Hash {
  Param (
    [Parameter(Mandatory = $true)][String]$localPath
  )


  If (Test-Path -Path $localPath) {
    try {
      # Create the hasher and get the content
      $hashFromFile = Get-FileHash -Path $localPath -Algorithm MD5
      $filehash_as_bytes = Convert-HashToByteArray($hashFromFile.Hash)
      $hash = [System.Convert]::ToBase64String($filehash_as_bytes)

    }
    catch {
      $hash = $null
    }
  }
  Else {
    # File doesn't exist, can't calculate hash
    $hash = $null
  }

  # Open $file as a stream

  # Return the Base64 encoded MD5 hash
  return $hash
}




$assetsFolder = (Join-Path $config.DeployFolder "assets")
$sitecoreWDPpathArray = New-Object System.Collections.ArrayList

$assetconfig.prerequisites | Where-Object {

  $_.uploadToAzure -eq $true } |

ForEach-Object {

  $sitecorePackages = Get-ChildItem -File -Path (Join-Path $assetsFolder $_.name) | ForEach-Object -Process { $_ }

  foreach ($scwdpinarray in  $sitecorePackages) {
    if ($null -eq $scwdpinarray) {
      continue
    }

    $sitecoreWDPpathArray.Add($scwdpinarray)
  }

}

$sitecoreWDPpathArray.Add($(Get-Item -Path $([IO.Path]::Combine($config.DeployFolder, 'assets', 'Sitecore Azure Toolkit', 'resources', $config.Version , 'Addons', 'Sitecore.Cloud.Integration.Bootload.wdp.zip')))) | out-null


## Upload function
foreach ($scwdpinarray in  $sitecoreWDPpathArray ) {
  if ($null -eq $scwdpinarray) {
    continue
  }
  Write-Host "Uploading '$($scwdpinarray.Name)'" -ForegroundColor Green
  $blobPath = "$($script:azureEnvironment.ToLower())/$($config.Hosting.ToLower())/$($config.Version)/$($scwdpinarray.Name)"

  if (!(CheckMD5 -localFilePath $scwdpinarray.FullName -remoteBlobPath $blobPath -container $wdpPackageContainerName -context $saContext.Context)) {
    $md5 = Get-MD5Hash -localPath  $scwdpinarray.FullName #Get-FileHash -Path $scwdpinarray.FullName -Algorithm MD5
    Set-AzStorageBlobContent -File $scwdpinarray.FullName -Blob $blobPath -Container $wdpPackageContainerName -Context $saContext.Context -Force -Properties @{"ContentMD5" = $md5 }
    Write-Host "Upload of '$($scwdpinarray.Name)' completed" -ForegroundColor Green
  }
  else {
    Write-Host "***  Skipping '$($scwdpinarray.Name)' - already exists" -ForegroundColor Green
  }
}
