<#
.SYNOPSIS
Prepare Local build environnment for transforming/uploading sitecore 9.x assets.

.DESCRIPTION
This script will check the local Deploy folder defined in the $ConfigurationFile file
for an Assets folder, and create one if it doesn't exist. It will then check the folder
for prerequisite files as defined by the assets.json. The script will then download anything missing
and extract tools and files so they can be used by later scripts.

.PARAMETER ConfigurationFile
A cake-config.json file
.PARAMETER SitecoreDownloadUsername
dev.sitecore.com username.
.PARAMETER SitecoreDownloadPassword
dev.sitecore.com password.
.PARAMETER OverrideFromAzure
overrides logic to download from Azure Storage account.

#>

[CmdletBinding(SupportsShouldProcess = $true)]
Param(
  [string] $ConfigurationFile = $(join-path (Split-Path -parent $PSScriptRoot) "\configuration\sbx\install.json"),
  #[string] $ConfigurationFile,
  [string] $devSitecoreUsername,
  [System.Security.SecureString] $devSitecorePassword,
  [bool] $OverrideFromAzure = $false
)

Push-location

Set-Location $PSScriptRoot

$ErrorActionPreference = "Stop"
$global:ProgressPreference = 'SilentlyContinue'

#Install Azure Powershell Az Module

Import-Module $PSScriptRoot\modules\saf\saf.psd1 -Force

$AzModule = Get-Module -ListAvailable "Az.*"

if ($AzModule.Count -gt 0) {
  Write-Host "Skipping installing AZ Module because it's already installed"
}
else {
  Write-Host "Installing AZ Module"
  Install-Module -Name Az -AllowClobber -Force
}


###########################
# Find configuration files
###########################

Write-Host "Calling ProcessConfigFile script: $ConfigurationFile"
$configarray = ProcessConfigFile -Config $ConfigurationFile
Write-Host "Executed ProcessConfigFile"
$config = $configarray[0]
$assetconfig = $configarray[1] #assets.json
$azureconfig = $configarray[2]
$azureconfigFile = $configArray[3]

############################
# Get Sitecore Credentials
############################

function Get-SitecoreCredentials {
  Write-Host "Executing Get-SitecoreCredentials"
  if ([string]::IsNullOrEmpty($script:devSitecoreUsername) -or [string]::IsNullOrEmpty($script:devSitecorePassword)) {

    if ([string]::IsNullOrEmpty($env:devSitecoreUsername) -or [string]::IsNullOrEmpty($env:devSitecorePassword)) {

      $cred = Get-Credential -Message "Please provide dev.sitecore.com credentials"
      $script:devSitecoreUserName = $cred.GetNetworkCredential().UserName
      $script:devSitecorePassword = ConvertTo-SecureString $cred.GetNetworkCredential().Password -AsPlainText -Force
    }
    else {

      $script:devSitecoreUserName = $env:devSitecoreUsername
      $script:devSitecorePassword = ConvertTo-SecureString $env:devSitecorePassword -AsPlainText -Force
    }
  }
  Write-Host "Executed Get-SitecoreCredentials"
}
Write-Host "Calling Get-SitecoreCredentials"
Get-SitecoreCredentials

Write-Host "Fetching Paramters"
$azureconfig | ConvertTo-Json | set-content $azureconfigFile

###################################
# Parameters
###################################

$foundfiles = New-Object System.Collections.ArrayList
$downloadlist = New-Object System.Collections.ArrayList
$assetsfolder = (Join-Path $config.DeployFolder assets)

Write-Host "Sitecore Username: $devSitecoreUsername"
Write-Host "Sitecore Password: $devSitecorePassword"

$credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $devSitecoreUsername, $devSitecorePassword

Write-Host "Fetched Paramters"
##################################################
# Check for existing Files in Deploy\Assets Folder
##################################################

Write-Host "Checking for prerequisite files"
Write-Host "Checking for files in" $assetsfolder

if (!(Test-Path $assetsfolder)) {
  Write-Host "Assets Folder does not exist"
  Write-Host "Creating Assets Folder"

  New-Item -ItemType Directory -Force -Path $assetsfolder
}

$localassets = Get-ChildItem -path $(Join-Path $assetsfolder *) -include *.zip -r


foreach ($_ in $localassets) {
  $foundfiles.Add($_.name) | out-null
}

if ($foundfiles) {
  Write-Host "Files found:"

  foreach ($_ in $assetconfig.prerequisites) {
    if ($_.install -eq $true) {
      if (($foundfiles -contains $_.fileName) -eq $true) {
        Write-Host `t $_.filename
        continue
      }
      elseif ($_.isGroup -eq "true") {
        foreach ($module in $_.modules) {
          if (($foundfiles -contains $module.fileName) -eq $true) {
            Write-Host `t $module.filename
            continue
          }
          else {
            $downloadlist.Add($module.fileName) | out-null
          }
        }
      }
      else {
        $downloadlist.Add($_.fileName) | out-null
      }
    }
  }

  if ($downloadlist) {
    Write-Host "Files Missing:"

    foreach ($_ in $downloadlist) {
      Write-Host `t $_
    }

  }
  else {
    Write-Host "All Local required files found"
  }
}
else {
  Write-Host "No Local files have been found"

  foreach ($_ in $assetconfig.prerequisites) {
    if ($_.install -eq $true) {
      if ($_.isGroup -eq "true") {
        foreach ($module in $_.modules) {
          $downloadlist.Add($module.fileName) | out-null
        }
      }
      else {
        $downloadlist.Add($_.fileName) | out-null
      }
    }
  }
}


############################
# Get Sitecore License
############################


Write-Host "Check For SitecoreLicenseXMLPath"
$licenseFileSetting = $azureconfig.settings | Where-Object { $_.id -eq "SitecoreLicenseXMLPath" }
if ($null -ne $licenseFileSetting) {
  Write-Host "SitecoreLicenseXMLPath found"
  $licenseXMLPath = $licenseFileSetting.value
}


function Get-LicenseFromEnvironmentVariable {
    Write-Host "Executing Get-LicenseFromEnvironmentVariable"
    if (([string]::IsNullOrEmpty($licenseXMLPath)) -or !(Test-Path $licenseXMLPath)) {
      # License file is not present
      Write-Verbose "License file is not present"      
      if ($null -ne $env:SITECORELICENSE) {
        Write-Verbose "Environment License is not null"
        $licenseXMLPath = Join-Path $config.DeployFolder "assets\license.xml"
        Write-FromLicenseEnvironmentVariable($licenseXMLPath);
        $licenseFileSetting.value = $licenseXMLPath
      }
      else {
        Write-Error "Could not locate the license file at $licenseXMLPath and environment variable does not have license content."
      }
    } else {
      Write-Host "Located the license file: $licenseXMLPath"
    }
    Write-Host "Executed Get-LicenseFromEnvironmentVariable"
}
Write-Host "Calling Get-LicenseFromEnvironmentVariable"
Get-LicenseFromEnvironmentVariable

###########################
# Download Required Files
###########################
<#
.SYNOPSYS
Downloads the asset from the provided hosting location.
#>
Function Download-Asset {
  [CmdletBinding(SupportsShouldProcess = $true)]
  param(   [PSCustomObject]
    $assetfilename,
    [PSCredential] $Credentials,
    $assetsfolder,
    $sourceuri,
    $sourceType
  )
  Write-Host "Downloading Asset"
  if (!(Test-Path $assetsfolder)) {

    Write-Host "Assets Folder does not exist"
    Write-Host "Creating Assets Folder"

    New-Item -ItemType Directory -Force -Path $assetsfolder
  }
  #Fetch from Azure if OverrideFromAzure flag is set
  if ($OverrideFromAzure) {
    Write-Host "Downloading $assetfilename from Azure storage." -ForegroundColor Green

    $blobName = "$($config.Hosting)/$($config.Version)/$assetfilename"
    $DestinationPath = Join-Path $assetsfolder $Assetfilename

    Get-AzStorageBlob -Container $($script:containerName.value) -Blob $blobName -Context $script:storageContext -ErrorAction "Stop" `
      | Get-AzStorageBlobContent -Destination $DestinationPath -Force
  }
  else { #Fetch from site core source
    Write-Host "Downloading $assetfilename from $sourceType." -ForegroundColor Green

    $params = @{
      Source        = $sourceuri
      Destination   = $assetsfolder
      Credentials   = $Credentials
      Assetfilename = $assetfilename
      TypeSource    = $sourceType
    }
    Write-Host "Invoking DownloadFileWithCredentialsTask"
    Invoke-DownloadFileWithCredentialsTask @params
  }
}
  
if ($downloadlist) {

  $script:storageContext = $null
  $script:containerName = $null
  Write-Host "Downloading necessary files"
    # $OverrideFromAzure is set to true then set azure storage context and container name once and use it for each prerequisite
   if ($OverrideFromAzure) {
      Write-Host "Get Storage account details"
      $storageAccountName = $azureconfig.settings | Where-Object { $_.id -eq "StorageAccountName" } 
      $script:containerName = $azureconfig.settings | Where-Object { $_.id -eq "WDPPackageBaseContainerName"}
      $script:storageContext = New-AzStorageContext -StorageAccountName $storageAccountName.value -UseConnectedAccount
      }
     
  foreach ($prereq in $assetconfig.prerequisites) {
    if ($prereq.isGroup -eq $true) {

      if (!(Test-Path $(Join-Path $assetsfolder $prereq.name))) {
        Write-Host $prereq.name "folder does not exist"
        Write-Host "Creating" $prereq.name "Folder"

        New-Item -ItemType Directory -Force -Path $(Join-Path $assetsfolder $prereq.name)
      }

      foreach ($module in $prereq.modules) {
        if (($downloadlist -contains $module.fileName) -eq $false) {
          continue
        }
        else {
          Download-Asset -assetfilename $module.fileName -Credentials $credential -assetsfolder $(Join-Path $assetsfolder $prereq.name) -sourceuri $module.url -sourceType $module.source
        }
      }
    }
    elseif ((($prereq.isWDP -eq $true) -or ($prereq.convertToWdp -eq $true)) -and ($downloadlist -contains $prereq.fileName)) {
      if (!(Test-Path $(Join-Path $assetsfolder $prereq.name))) {
        Write-Host $prereq.name "folder does not exist"
        Write-Host "Creating" $prereq.name "Folder"

        New-Item -ItemType Directory -Force -Path $(Join-Path $assetsfolder $prereq.name)
      }

     
      Download-Asset -assetfilename $prereq.fileName -Credentials $credential -assetsfolder $(Join-Path $assetsfolder $prereq.name) -sourceuri $prereq.url -sourceType $prereq.source

    }
    elseif (($downloadlist -contains $prereq.fileName) -eq $false) {
      continue
    }
    else {
      Download-Asset -assetfilename $prereq.fileName -Credentials $credential -assetsfolder $assetsfolder -sourceuri $prereq.url -sourceType $prereq.source
    }
  }

  Write-Host "Downloaded Host"
}

<#
.SYNOPSIS
  Extracts the archive files downloaded from Sitecore developer site or Azure storage file

.DESCRIPTION
  This function is responsible for extracing the archive files into target folders based on the given configuration.
#>
function Expand-Files {
  [CmdletBinding()]
  Param()
  Write-Host "Expanding Files"
  $localassets = Get-ChildItem -path $(Join-Path $assetsfolder *) -include *.zip -r

  foreach ($_ in $assetconfig.prerequisites) {
    if ((($localassets.name -contains $_.fileName) -eq $true) -and ($_.extract -eq $true)) {
      # This is a bug fix due to the DotNetZip.dll getting locked if the build is ran multiple times
      if (($_.name -eq "Sitecore Azure Toolkit") -and $(Test-Path $([io.path]::combine($assetsfolder, $_.name, 'tools', 'DotNetZip.dll')))) {
        Write-Host $_.name "found, skipping extraction"
        continue
      }
      elseif ($_.name -eq "Sitecore Experience Platform") {
        if (($config.Topology -eq "xp0") -and $(Test-Path -Path "$($assetsfolder)\$($_.name)\*xp0*")) {
          Write-Host $_.name "found, skipping extraction"
          continue
        }
        elseif (($config.Topology -eq "xp1") -and $(Test-Path -Path "$($assetsfolder)\$($_.name)\*xp1*")) {
          Write-Host $_.name "found, skipping extraction"
          continue
        }
      }

      Write-Host "Extracting" $_.filename -ForegroundColor Green

      Expand-Archive	-Path $(Join-path $assetsfolder $_.filename) -DestinationPath $(Join-path $assetsfolder $_.name) -force
    }
    elseif ($_.isGroup -eq $true) {
      foreach ($module in $_.modules) {
        if ((($localassets.name -contains $module.fileName) -eq $true) -and ($module.extract -eq $true)) {

          if (!(Test-Path $(Join-Path $assetsfolder $_.name))) {
            Write-Host $_.name "folder does not exist"
            Write-Host "Creating" $_.name "Folder"

            New-Item -ItemType Directory -Force -Path $(Join-Path $assetsfolder $_.name)
          }

          Write-Host "Extracting" $module.filename -ForegroundColor Green
          Expand-Archive	-Path $(Join-path $assetsfolder $module.filename) -DestinationPath $(Join-path $assetsfolder $_.name) -force
        }
      }
    }
  }
  Write-Host "Expanded Files"
}
Write-Host "Calling Expand Files"
Expand-Files

Push-location