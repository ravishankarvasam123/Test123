<#
.SYNOPSIS
  Perofrms the cold restore of the designated Sitecore environment databases in teh secondary region.

.PARAMETER ConfigurationFilePath
  The full full path of the enviornment configuration file.
#>
[CmdletBinding()]
Param(
  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [String] $ConfigurationFile,
  [Parameter(Mandatory = $false)]
  [string] $TargetDatabaseNameSuffix ="-new"
)


Import-Module "$PSScriptRoot/modules/saf/saf.psd1" -Force -PassThru -DisableNameChecking

$configArray = ProcessConfigFile -Config $ConfigurationFile
$config = $configArray[0]
$azureconfig = $configArray[2]

$subscriptionSetting = $azureconfig.settings | Where-Object { $_.id -eq "SubscriptionName" }

$azurePrefixSetting = $azureconfig.settings | Where-Object { $_.id -eq "prefix" }
$azurePrefix = $azurePrefixSetting.value

#if the parameter DeploymentEnvironment is not null then set the environment  from the parameter
$azureEnvironmentSetting = $azureconfig.settings | Where-Object { $_.id -eq "environment" }
$azureEnvironment = $azureEnvironmentSetting.value
if (-not [string]::IsNullOrEmpty($env:Environment)) {
  $azureEnvironment = $env:Environment
}

if ($null -ne $subscriptionSetting) {
  $subscription = $subscriptionSetting.value
}

$azContext = Get-AzContext

if ($null -eq $azContext) {

  ## Connect to Azure
  Connect-AzAccount -Subscription $subscription
  $azContext = Get-AzContext
}
else {
  if ($null -ne $subscription -and $subscription -ne $azContext.Subscription.Name) {
    throw "Configured subscription $subscription does not match context subscription $($azContext.Subscription.Name)."
  }
}

$sourceResourceGroup = "$azurePrefix-$azureEnvironment-sitecore-platform-rg"
$sourceSqlServer = "$azurePrefix-$azureEnvironment-sc-sql"
$targetResourceGroup = "$azurePrefix-$azureEnvironment-sc-dr-rg"
$targetSqlServer = "$azurePrefix-$azureEnvironment-sc-dr-sql"

try {
  Restore-SitecoreSqlDatabases `
          -SourceResourceGroup $sourceResourceGroup `
          -SourceServerName $sourceSqlServer `
          -TargetResourceGroup $targetResourceGroup `
          -TargetServerName $targetSqlServer -TargetDatabaseNameSuffix $TargetDatabaseNameSuffix  -Verbose:$VerbosePreference
}
catch {
  Write-Host "Error occurred during restoration $($_.Message)"
  Write-Host $_.Exception
}