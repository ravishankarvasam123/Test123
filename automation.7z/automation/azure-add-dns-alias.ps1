[CmdletBinding()]
Param(
  [Parameter(Mandatory=$true)]
  [string] $cmAlias = "uat-sc-cm",
  [Parameter(Mandatory=$true)]
  [string] $cdAlias = "uat-sc-cd",
  [Parameter(Mandatory=$true)]
  [string] $publicIpName = "bh-dbt-dev-shared-internal-appgw-pip",
  [Parameter(Mandatory=$true)]
  [string] $dnsZone = "dbt.testbhealth.com",
  [Parameter(Mandatory=$true)]
  [string] $rgName = "bh-dbt-nonprod-shared-rg"
)

# $cmAlias = "uat-sc-cm"
# $cdAlias = "uat-sc-cd"
# $publicIpName = "bh-dbt-dev-shared-internal-appgw-pip"
# $dnsZone = "dbt.testbhealth.com"
# $rgName = "bh-dbt-nonprod-shared-rg"

Function AddDNSAlias {
    param(     
      [string] $name, [string] $publicIpName, [string] $dnsZone, [string] $rgName
    )
        #https://docs.microsoft.com/en-us/azure/traffic-manager/traffic-manager-powershell-arm

        try
        {
        $trafficRoutingMethod = "Weighted"
        $epName = "nonprd-appgw-int-endpoint"
        
        try{
        #Get the traffic manager profile
        $tmProfile = Get-AzTrafficManagerProfile -Name $name -ResourceGroupName $rgName -ErrorAction SilentlyContinue
        }
        catch {  
            Write-Host $_.Exception 
        }
       
        #Get the public ip
        $publicIp = Get-AzPublicIpAddress -Name $publicIpName -ResourceGroupName $rgName

        #Create Traffic manager profile if does not exists
        if($tmProfile -eq $null){
            $tmProfile = New-AzTrafficManagerProfile -Name $name -ResourceGroupName $rgName -TrafficRoutingMethod $trafficRoutingMethod -RelativeDnsName $name -Ttl 60 -MonitorProtocol HTTP -MonitorPort 80 -MonitorPath "/"  
            write-host "----> $name : traffic manager profile created successfully "
            Start-Sleep -s 60
        }
        else{
            write-host "----> $name : traffic manager profile already exists"
        }

        #get the end point from the traffic manager profile
        $endpoint = $tmProfile.Endpoints | where-object { $_.Name -eq  $epName }

        #add the endpoint to traffic manager profile  if does not exists, else update it.
        if($publicIp -ne $null -and $endpoint -eq $null){    
            ##################### Creating new end point #####################################
            Add-AzTrafficManagerEndpointConfig -EndpointName $epName -TrafficManagerProfile $tmProfile -Type AzureEndpoints -TargetResourceId $publicIp.Id -EndpointStatus Enabled
            Set-AzTrafficManagerProfile -TrafficManagerProfile $tmProfile
            write-host $endpoint.Name " -----> endpoint added successfully"
        }
        elseif($publicIp -ne $null -and $endpoint -ne $null){
            ########################## Updating existing end point ############################
            write-host $endpoint.Name " ----> endpoint already exists. updating public ip..."
            $endpoint.TargetResourceId = $publicIp.Id 
            $endpoint.Weight = 100
            Set-AzTrafficManagerEndpoint -TrafficManagerEndpoint $endpoint             
            write-host $endpoint.Name " ----> endpoint public ip updated successfully"
        }

        #write-host "----> Name: " $tmProfile.Name ", Resource Group Name: " $tmProfile.ResourceGroupName ", TrafficRoutingMethod: " $tmProfile.TrafficRoutingMethod  ", Relative DNS Name: " $tmProfile.RelativeDnsName ", Monitor Protocol: " $tmProfile.MonitorProtocol ", Monitor Port: " $tmProfile.MonitorPort ", Monitor Path: " $tmProfile.MonitorPath

        ########################### DNS Zone - Adding Record Set ###########################################
        #Link - https://docs.microsoft.com/en-us/azure/dns/dns-operations-recordsets#create-records-of-other-types

        #Get the dns zone
        $zone = Get-AzDnsZone -Name $dnsZone -ResourceGroupName $rgName
        $recordSetName = $name #"sbx-sc-cm"

        try{
        #Get DNS record set from DNS zone.
        $rs = Get-AzDnsRecordSet -Name $recordSetName -RecordType CNAME -Zone $zone -ErrorAction SilentlyContinue
        }
        catch {
            Write-Host $_.Exception
        }

        #Add the record set if does not exists, else update it.
        #Here, Record set point to the, Traffic manager profile
        if($rs -ne $null -and $tmProfile -ne $null){            
            write-host $rs.Name " ----> updated the existing dns record set with traffic manager profile"
            $rs.TargetResourceId = $tmProfile.id
            Set-AzDnsRecordSet -RecordSet $rs
            write-host "----> $recordSetName DNS Alias updated successfully."
        }
        elseif($rs -eq $null -and $tmProfile -ne $null){
            New-AzDnsRecordSet -Name $recordSetName -RecordType CNAME -ZoneName $zone.Name -ResourceGroupName $rgName -Ttl 3600 -TargetResourceId $tmProfile.id
            write-host "----> $recordSetName DNS Alias added successfully."
        }      
        #########################################################################################################
    }
    catch{
        Write-Host $_.Exception
    }
}

#Add CM Alias
AddDNSAlias -name $cmAlias -publicIpName $publicIpName -dnsZone $dnsZone -rgName $rgName

#Add CD Alias
AddDNSAlias -name $cdAlias -publicIpName $publicIpName -dnsZone $dnsZone -rgName $rgName