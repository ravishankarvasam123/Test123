Remove-Module (Join-Path $PSScriptRoot './modules/saf/saf.psd1') -ErrorAction Ignore

Import-Module (Join-Path $PSScriptRoot './modules/saf/saf.psd1')