#Requires -Module Az.Accounts, Az.Resources

<#
  This script deploys Sitecore to Azure based on the target settings.
#>

[CmdletBinding(SupportsShouldProcess = $true)]
Param(
  [Parameter(Mandatory = $true)]
  [string] $ConfigurationFile = $(join-path (Split-Path -parent $PSScriptRoot) "\configuration\sbx\install.json"),
  [Parameter(Mandatory = $true)]
  [string] $armTemplateParameterPath = $(join-path (Split-Path -parent $PSScriptRoot) "\configuration\sbx\azuredeploy.parameters.json"),
  [Parameter(Mandatory = $false)]
  [ValidateSet("local", "sbx", "dev", "qa", "uat", "prd")]
  [string] $DeploymentEnvironment,
  [Parameter(Mandatory = $false)]
  [Switch] $FullRebuild
)

Push-Location

Set-Location $PSScriptRoot



Import-Module "$PSScriptRoot/modules/saf/saf.psd1" -Force -PassThru

## Create / Ensure Self-Signed XConnect Certificate
Create-XCCertificate -ConfigurationFile $ConfigurationFile


$configArray = ProcessConfigFile -Config $ConfigurationFile
$config = $configArray[0]
$azureconfig = $configArray[2]


## Get required settings for sitecore-azure deployment
$azurePrefixSetting = $azureconfig.settings | Where-Object { $_.id -eq "prefix" }
$azurePrefix = $azurePrefixSetting.value

#if the parameter DeploymentEnvironment is not null then set the environment  from the parameter
$azureEnvironmentSetting = $azureconfig.settings | Where-Object { $_.id -eq "environment" }
$azureEnvironment = $azureEnvironmentSetting.value
if (-not [string]::IsNullOrEmpty($DeploymentEnvironment)) {
  $azureEnvironment = $DeploymentEnvironment
}

$storageAccountNameSetting = $azureconfig.settings | Where-Object { $_.id -eq "StorageAccountName" }
$storageAccoutName = $storageAccountNameSetting.value

$adminResourceGroupSetting = $azureconfig.settings | Where-Object { $_.id -eq "AzureAdminResourceGroup" }
$adminResourceGroup = $adminResourceGroupSetting.value

$azureRegionSetting = $azureconfig.settings | Where-Object { $_.id -eq "AzureRegion" }
if ($null -ne $azureRegionSetting) {
  $azureRegion = $azureRegionSetting.value
}
elseif ($null -ne $env:AZUREREGION) {
  $azureRegion = $env:AZUREREGION
}

$sitecoreSKUSetting = $azureconfig.settings | Where-Object { $_.id -eq "SitecoreSKU" }
if ($null -ne $sitecoreSKUSetting) {
$sitecoreSKU = $sitecoreSKUSetting.value
}
if ($null -ne $env:SitecoreSKU) {
  $sitecoreSKU = $env:SitecoreSKU
}

$certFilePathSetting = $azureconfig.settings | Where-Object { $_.id -eq "XConnectCertfilePath" }
$certFilePath = $certFilePathSetting.value

$templateContainerNameSetting = $azureconfig.settings | Where-Object { $_.id -eq "TemplateContainerName" }
$templateContainerName = $templateContainerNameSetting.value

$licenseXMLPathSetting = $azureconfig.settings | Where-Object { $_.id -eq "SitecoreLicenseXMLPath" }
if ($null -ne $licenseXMLPathSetting -and !([string]::IsNullOrEmpty($licenseXMLPathSetting.value))) {
  Write-Verbose "LicenseXmlPath is present"
  $licenseXMLPath = $licenseXMLPathSetting.value
}
elseif ($null -ne $env:SITECORELICENSE) {
  Write-Verbose "LicenseXmlPath is not present fetching from environment variable"
  $licenseXMLPath = Join-Path $config.DeployFolder "assets\license.xml"
  Write-FromLicenseEnvironmentVariable($licenseXMLPath)
  Write-Verbose "Fetched License Content from Environment variable: $licenseXMLPath"
}

$templateLinkAccessTokenSetting = $azureconfig.settings | Where-Object { $_.id -eq "TemplateLinkAccessToken" }
if ($null -ne $templateLinkAccessTokenSetting) {
  $templateLinkAccessToken = $templateLinkAccessTokenSetting.value
}

$subscriptionSetting = $azureconfig.settings | Where-Object { $_.id -eq "SubscriptionName" }

if ($null -ne $subscriptionSetting) {
  $subscription = $subscriptionSetting.value
}



Import-Module "$($config.DeployFolder)/assets/Sitecore Azure Toolkit/tools/Sitecore.Cloud.Cmdlets.psm1"

$azContext = Get-AzContext

if ($null -eq $azContext) {

  ## Connect to Azure
  Connect-AzAccount -Subscription $subscription
  $azContext = Get-AzContext
}
else {
  if ($null -ne $subscription -and $subscription -ne $azContext.Subscription.Name) {
    throw "Configured subscription $subscription does not match context subscription $($azContext.Subscription.Name)."
  }
}

## Get SAS Token token, generated
if ($null -eq $templateLinkAccessToken) {
  Write-Verbose "No SAS Token provided in azure-config.json. Creating ..."
  $saContext = (Get-AzStorageAccount -Name $storageAccoutName -ResourceGroupName $adminResourceGroup).Context
  $templateLinkAccessToken = New-AzStorageAccountSASToken -Context $saContext -Protocol HttpsOnly -Service Blob -ResourceType Service, Container, Object -Permission rl -ExpiryTime ([DateTime]::Now.AddHours(3))
  Write-Verbose "Created SAS Token for storage account $($saContext.Name): $templateLinkAccessToken"
}

## Generate the dynamic value parameters (will be merged with static values in azuredeploy.parameters.json)
$authCertificateBlob = [System.Convert]::ToBase64String([System.IO.File]::ReadAllBytes($certFilePath));
Write-Verbose "Auth Certificate File Path: $certFilePath"

$blobPrefix = "$($azureEnvironment.ToLower())/$($config.Hosting.ToLower())/$($config.Version)/"
$armTemplateBaseUri = $saContext.BlobEndPoint + $templateContainerName + "/$blobPrefix"
Write-Verbose "Arm Template Base Uri: $armTemplateBaseUri"
$armTemplateUri = $armTemplateBaseUri + "azuredeploy.json" + $templateLinkAccessToken
Write-Verbose "Arm Template Uri: $armTemplateUri"

$deploymentId = "{0}-{1}-{2}" -f $azurePrefix, $azureEnvironment, "sc"
Write-Verbose "Deployment Id: $deploymentId"
$resourceGroupName = "{0}-{1}-sitecore-platform-rg" -f $azurePrefix, $azureEnvironment

$disasterRecoveryRestore = $false
# For cold stand by disastar recovery, set the disaster recovery recource group as the primary resource group
if (($null -ne $env:disasterRecoveryRestore) -and ([System.Convert]::ToBoolean($env:disasterRecoveryRestore))){
  $resourceGroupName = "{0}-{1}-sc-dr-rg" -f $azurePrefix, $azureEnvironment
  $env:drEnabled = $false
  $disasterRecoveryRestore = $true
  $FullRebuild = $false
  $deploymentId = "{0}-{1}-{2}" -f $azurePrefix, $azureEnvironment, "sc-dr"
}

#set the resource group for DR region
$secondaryResourceGroup = "{0}-{1}-sc-dr-rg" -f $azurePrefix, $azureEnvironment

if (($null -ne $env:drEnabled) -and ([System.Convert]::ToBoolean($env:drEnabled))){
  #Check if secondaryResourceGroup exists, if not then set it same as primary resource group for template validation purpose if drEnabled = false else throw error
  Get-AzResourceGroup -Name $secondaryResourceGroup -ErrorVariable rgNotPresent -ErrorAction SilentlyContinue
  if ($rgNotPresent){
     throw "Secondary resource group $secondaryResourceGroup does not exists"
  }
}


$setKeyValue = @{
  templateLinkBase        = $armTemplateBaseUri
  authCertificateBlob     = $authCertificateBlob
  templateLinkAccessToken = $templateLinkAccessToken
  deploymentId            = $deploymentId
  secondaryResourceGroup  = $secondaryResourceGroup
  disasterRecoveryRestore = $disasterRecoveryRestore
}

# Generate dynamic value for MsDeployPackageUrl that are referred in azuredeploy.parameters.json
# Get all packages base Name
$packageBaseNames = @{
  "cd"               = "Sitecore 9.2.0 rev. 002893 (Cloud)_cd.scwdp.zip";
  "cm"               = "Sitecore 9.2.0 rev. 002893 (Cloud)_cm.scwdp.zip";
  "si"               = "Sitecore.IdentityServer.3.0.0-r00211.scwdp.zip";
  "prc"              = "Sitecore 9.2.0 rev. 002893 (Cloud)_prc.scwdp.zip";
  "rep"              = "Sitecore 9.2.0 rev. 002893 (Cloud)_rep.scwdp.zip";
  "xcRefData"        = "Sitecore 9.2.0 rev. 002893 (Cloud)_xp1referencedata.scwdp.zip";
  "xcCollect"        = "Sitecore 9.2.0 rev. 002893 (Cloud)_xp1collection.scwdp.zip";
  "xcSearch"         = "Sitecore 9.2.0 rev. 002893 (Cloud)_xp1collectionsearch.scwdp.zip";
  "cortexProcessing" = "Sitecore 9.2.0 rev. 002893 (Cloud)_xp1cortexprocessing.scwdp.zip";
  "cortexReporting"  = "Sitecore 9.2.0 rev. 002893 (Cloud)_xp1cortexreporting.scwdp.zip";
  "maOps"            = "Sitecore 9.2.0 rev. 002893 (Cloud)_xp1marketingautomation.scwdp.zip";
  "maRep"            = "Sitecore 9.2.0 rev. 002893 (Cloud)_xp1marketingautomationreporting.scwdp.zip";
  "bootLoader"       = "Sitecore.Cloud.Integration.Bootload.wdp.zip";
  "spe"              = "Sitecore PowerShell Extensions-5.0 for 9.2.scwdp.zip";
  "empty"            = "Empty.scwdp.zip";
  "contentExporter"  = "Content.Export.Tool.20200630.scwdp.zip";
}

# Form the list of packages that can be transformed
$basePackageNamesToTransform = [System.Collections.ArrayList]@(
  "Sitecore 9.2.0 rev. 002893 (Cloud)_cd.scwdp.zip",
  "Sitecore 9.2.0 rev. 002893 (Cloud)_cm.scwdp.zip",
  "Sitecore 9.2.0 rev. 002893 (Cloud)_prc.scwdp.zip",
  "Sitecore 9.2.0 rev. 002893 (Cloud)_rep.scwdp.zip"
)


$packageContainerNameSetting = $azureconfig.settings | Where-Object { $_.id -eq "WDPPackageContainerName" }
$packageContainerName = $packageContainerNameSetting.value
$basePath = "$($packageContainerName.ToLower())/$($azureEnvironment.ToLower())/$($config.Hosting.ToLower())/$($config.Version)"


#generate package url by calling function Format-PackageBlobUrl
$packageBaseNames.GetEnumerator() | ForEach-Object {
  $pkgUrl = Format-PackageBlobUrl `
    -PackageBaseName $_.Value `
    -StorageAccountName $storageAccoutName `
    -TemplateBasePath $basePath `
    -TemplateAccessToken $templateLinkAccessToken `
    -GenerateNoDatabaseNameFragment:((-not $FullRebuild) -and ($basePackageNamesToTransform.contains($_.Value)))
      $setKeyValue.Add("$($_.Name)MsDeployPackageUrl", $pkgUrl)
     Write-Verbose "No db wdp package url after transformed: $pkgUrl"

}

#For disasterRecoveryRestore, set the deployXConnect to true
if (($false -eq $FullRebuild) -and ($false -eq $disasterRecoveryRestore )) {
  $setKeyValue.Add("deployXConnect", "false")
}
elseif($disasterRecoveryRestore -eq $true)
{
  $setKeyValue.Add("deployXConnect", "true")
}


if ($null -ne $sitecoreSKU) {
$setKeyValue.Add("sitecoreSKU", $sitecoreSKU)
}


#Flag to check if SQL Session DB should be deployed or not
if ($null -ne $env:deploySQLSessionDB) {
  $setKeyValue.Add("deploySqlSessionDB", $env:deploySQLSessionDB)
}

# update the value of data volume cap from release task if required
if ($null -ne $env:applicationInsightsDataVolumneCap) {
  $setKeyValue.Add("applicationInsightsDataVolumneCap", $env:applicationInsightsDataVolumneCap)
}

#Get custom domain certificate thumbprint for adding custom domain to CM app service

$cmCustDomainCertKeyVaultName = $azureconfig.settings | Where-Object { $_.id -eq "CMCustomDomainCertKeyVault" }
$cmCustDomainCertKeyVaultSecret = $azureconfig.settings | Where-Object { $_.id -eq "CMCustomDomainCertificateName" }

$custDomainCert = $null

if(($null -ne $cmCustDomainCertKeyVaultName) -and ($null -ne $cmCustDomainCertKeyVaultSecret)){
$custDomainCert = Get-AzKeyVaultCertificate -VaultName $cmCustDomainCertKeyVaultName.value -Name $cmCustDomainCertKeyVaultSecret.value
$SetKeyValue.Add("cmCustDomainCertKeyVaultName",$cmCustDomainCertKeyVaultName.value)
$SetKeyValue.Add("cmCustDomainCertKeyVaultSecret",$cmCustDomainCertKeyVaultSecret.value)
}

if($null -ne $custDomainCert){
$setKeyValue.Add("cmCustDomainCertThumbprint", $custDomainCert.Thumbprint)
}
else{
#Set default value
$setKeyValue.Add("cmCustDomainCertThumbprint","")
}



# Ensure Azure Region is provided to the Sitecore Command
if ($null -eq $azureRegion) {
  $resourceGroupObj = get-AzResourceGroup -context $azContext -Name $resourceGroupName

  if ($null -ne $resourceGroupObj) {
    $azureRegion = $resourceGroupObj.Location
  }
}

#useMonitoringModule flag if set to true = monitoring module will deploy and false = not deploy module
if ($null -ne $env:useMonitoringModule) {
  $setKeyValue.Add("useMonitoringModule",$env:useMonitoringModule)
}



if ($null -ne $env:omsWorkspaceAlertRecipients) {
  $setKeyValue.Add("omsWorkspaceAlertRecipients",$env:omsWorkspaceAlertRecipients)
}
if ($null -ne $env:omsWorkspaceMetricsRetentionDays) {
  $setKeyValue.Add("omsWorkspaceMetricsRetentionDays",[int] $env:omsWorkspaceMetricsRetentionDays)
}
# If resetMonitoringAlerts = false then it does not impact or reset Alerts,action group and availibility alerts and
# resetMonitoringAlerts = true is set then it reset all alerts,actiongroup,availibility test alerts
if ($null -ne $env:resetMonitoringAlerts) {
$alertsFlag = [System.Convert]::ToBoolean($env:resetMonitoringAlerts)
  $setKeyValue.Add("resetMonitoringAlerts",$alertsFlag)
}

#drEnabled flag is set to enable secondary disastar recovery resource creation
if($null -ne $env:drEnabled){
  $setKeyValue.Add("drEnabled",[System.Convert]::ToBoolean($env:drEnabled))
}

Write-Verbose "A list of dynamic Parameters: "
$setKeyValueColumnWidth = $hashTable.Keys.length | Sort-Object | Select-Object -Last 1
$setKeyValue.GetEnumerator() | ForEach-Object {
  Write-Verbose ("  {0,-$setKeyValueColumnWidth} : {1}" -F $_.Key, $_.Value) -Verbose
}

# Add Banner Policy Tags
if($null -ne $env:businessOwner){
$setKeyValue.Add("businessOwner", $env:businessOwner)
}

if($null -ne $env:technicalOwner){
$setKeyValue.Add("technicalOwner", $env:technicalOwner)
}

if($null -ne $env:accountingUnit){
$setKeyValue.Add("accountingUnit", $env:accountingUnit)
}

if($null -ne $env:dataClassification){
$setKeyValue.Add("dataClassification", $env:dataClassification)
}

if($null -ne $env:environmentTag){
$setKeyValue.Add("environmentTag", $env:environmentTag)
}

if($null -ne $env:sofia){
$setKeyValue.Add("sofia", $env:sofia)
}


if(-not [string]::IsNullOrEmpty($azureEnvironment))
{
  $setKeyValue.Add("environment",$azureEnvironment)
}

## Start Deployment

try {

  Write-Verbose "Start Deployment"
  if ($PSCmdlet.ShouldProcess($resourceGroupName, "Start Deployment of Sitecore Environment")) {
    Write-Verbose "Starting Deployment"
    Write-Verbose "Sitecore Azure Deployment Parameters: "
    Write-Verbose "Azure Region: $azureRegion"
    Write-Verbose "ResourceGroupName $resourceGroupName"
    Write-Verbose "ArmTemplateUrl $armTemplateUri"
    Write-Verbose "Azure Parameters Path: $armTemplateParameterPath"
    Write-Verbose "LicenseXmlPath: $licenseXMLPath"
    Write-Verbose "SetKeyValue: $setKeyValue"

    $tools = "$($config.DeployFolder)\assets\Sitecore Azure Toolkit\tools"

    SitecoreAzureDeployment -Verbose:$PSDefaultParameterValues["Verbose"].IsPresent `
      -ToolkitFolderPath $tools `
      -Location $azureRegion `
      -Name $resourceGroupName `
      -ArmTemplateUrl $armTemplateUri `
      -ArmParametersPath $armTemplateParameterPath `
      -LicenseXmlPath $licenseXMLPath `
      -SetKeyValue $setKeyValue

    function WriteDeploymentParameters {
      param (
        [string] $resourceGroupName
      )

      #Link: https://stackoverflow.com/questions/36948549/how-do-i-use-arm-outputs-values-another-release-task

      $lastDeployment = Get-AzResourceGroupDeployment -ResourceGroupName $resourceGroupName -Name $resourceGroupName | Sort-Object Timestamp -Descending | Select-Object -First 1

      if (!$lastDeployment) {
        throw "Deployment could not be found for Resource Group '$resourceGroupName'."
      }

      if (!$lastDeployment.Parameters) {
        throw "No parameters could be found for the last deployment of Resource Group '$resourceGroupName'."
      }

      #Write resource group name
      Write-Host "##vso[task.setvariable variable=rgName;]$resourceGroupName"

      foreach ($key in $lastDeployment.Parameters.Keys) {
        $type = $lastDeployment.Parameters.Item($key).Type
        $value = $lastDeployment.Parameters.Item($key).Value
        Write-Verbose "key: $key Value: $value"
        #write only web app names
        if ($key.ToLower() -like "*webappname") {
          if ($type -eq "SecureString") {
            Write-Host "##vso[task.setvariable variable=$key;issecret=true]$value"
          }
          else {
            Write-Host "##vso[task.setvariable variable=$key;]$value"
          }
        }
        elseif($key.ToLower() -like "*webappnamesecondary"){
         if ($type -eq "SecureString") {
            Write-Host "##vso[task.setvariable variable=$key;issecret=true]$value"
          }
          else {
            Write-Host "##vso[task.setvariable variable=$key;]$value"
          }
        }
      }
    }

    WriteDeploymentParameters -resourceGroupName $resourceGroupName

    Write-Host "Deployment completed ..."
  }
  else {

    $WhatIfPreference = $false
    Write-Host "Inside test condition"

    Import-Module "$($config.DeployFolder)/assets/Sitecore Azure Toolkit/tools/Sitecore.Cloud.Cmdlets.dll"

    # Set the Parameters in Arm Template Parameters Json
    $paramJson = Get-Content $armTemplateParameterPath -Raw -Force

    Write-Host "Setting ARM template parameters..."

    # Read and Set the license.xml
    $licenseXml = Get-Content $licenseXMLPath -Raw -Encoding UTF8 -Force
    $SetKeyValue.Add("licenseXml", $licenseXml)

    #For testing
    $armTemplateUri = $(join-path (Split-Path -parent $PSScriptRoot) "\templates\cloud-9.2.0-xp1\azuredeploy.json")

    # Update params and save to a temporary file
    $paramJsonFile = New-TemporaryFile
    Set-SCAzureDeployParameters -ParametersJson $paramJson -SetKeyValue $SetKeyValue | Set-Content $paramJsonFile  -Encoding UTF8 -Force

    Test-AzResourceGroupDeployment -ResourceGroupName $resourceGroupName -TemplateParameterFile $paramJsonFile -TemplateFile $armTemplateUri

    Remove-Item $paramJsonFile
  }
}
catch {

  Write-Verbose  "Encountered an error when deploying ... "
  Write-Host $_.Exception

  Write-Host "Deployment failed ..."

  throw;

}

Pop-Location