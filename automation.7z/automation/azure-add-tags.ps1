[CmdletBinding()]
Param(
  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [String] $SubscriptionName,  
  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [String] $ResourceGroupName,
  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [hashtable] $AzureTags

)


<#
Guidance on how to call this Script e.g. SBX resource group.
1.Construct object with required tag key/value pair & execute below in windows power-shell.

$tagsObject = @{   
    'BusinessOwner' = 'Colleen Weiss-Ramirez'
    'TechnicalOwner' = 'Matt Peterson'
    'Accounting Unit'    = '0101-9086195-000000'    
    'DataClassification' = 'Public'
    'Environment'     = 'LAB'
    'Sofia'  = 'No'
}

2.Execute below line.
.\azure-add-tags.ps1 -SubscriptionName 'BHDBTNonProduction' -ResourceGroupName 'bh-dbt-sbx-sitecore-platform-rg' -AzureTags $tagsObject

#>

 $module = Get-InstalledModule -Name "Az"

 if($module -eq $null){

 # Install AZ powershell module if it is not install previously
 try{

  Write-Host "Installing AZ module version 3.6.1"
  Install-Module -Name "Az" -RequiredVersion 3.6.1 -Repository 'PSGallery'
  Get-Job | Wait-Job | Out-Null

  }
  catch{
  throw "error occured while installing AZ module."
 }

 }elseif ($module.Version -lt '3.6.1'){


$moduleVersion = $module.Version
$title   = 'Install AZ Powershell Module'
$msg     = "Currently installed AZ module version in your local is $moduleVersion. AZ module version minimum 3.6.1 or greater is required to add azure tag via powershell. Do you want to upgrade AZ module from version $moduleVersion to 3.6.1."
$options = '&Yes', '&No'
$default = 1  # 0=Yes, 1=No

 $response = $Host.UI.PromptForChoice($title, $msg, $options, $default)
 if ($response -eq 1) {
        return ;
    }
    else{

    try{

  Write-Host "Installing AZ module version 3.6.1"
  Install-Module -Name "Az" -RequiredVersion 3.6.1 -Repository 'PSGallery'
  Get-Job | Wait-Job | Out-Null

  }
  catch{

  throw "error occured while installing AZ module version 3.6.1."

 }}

 }


if($module.Version -ge '3.6.1'){

$azContext = Get-AzContext

if($null -eq $azContext) {

  ## Connect to Azure
  Connect-AzAccount  
  Set-AzContext -Subscription $SubscriptionName
  $azContext = Get-AzContext  
}
else {

  if($null -ne $SubscriptionName -and $SubscriptionName -ne $azContext.Subscription.Name) {
    throw "subscription provided $SubscriptionName does not match context subscription $($azContext.Subscription.Name).Disconnect current az account using command 'Disconnect-AzAccount' & try again. "
  }
}

Write-Host $azContext.Subscription.Name

# Add tags at resource group level...
$resourceGroup = Get-AzResourceGroup -Name $ResourceGroupName -ErrorAction SilentlyContinue

if($resourceGroup -eq $null){

Write-Host "Provided resource group $resourceGroup does not exist in subscription $SubscriptionName"  -foregroundcolor Red

}else{

try{

Update-AzTag -ResourceId $resourceGroup.ResourceId -Tag $AzureTags -Operation Merge
Write-Host "Script Completed ...." -foregroundcolor Green

}catch{

Write-Host "Error occurred while adding tags." -foregroundcolor Red

}

}}