<#
.SYNOPSIS
This script deploys WAF Policy resource and assigns it to the Application Gateway

.PARAMETER wafPolicyName
The name of the WAF Policy Resource

.PARAMETER resourceGroupName
The resource group name where Application Gateway and WAF Policy Resource needs to be deployed

.PARAMETER appGWName
The application gateway name

.PARAMETER customRuleName
The name of the custom rule

.PARAMETER customRulePriority
The priority of the custom rule, recommendation is to keep in the sets of 5

.PARAMETER keywordToBlock
The keyword that we want to block in the request uri

.EXAMPLE
.\dbt-sitecore-platform\infra\automation\create-waf-policy.ps1 -wafPolicyName "bh-dbt-dev-shared-internal-wafpolicy"`
 -resourceGroupName "bh-dbt-nonprod-shared-rg" `
 -appGWName "bh-dbt-dev-shared-internal-appgw" `
 -customRuleName "BlockAutodiscover" `
 -customRulePriority 10 `
 -keywordToBlock "autodiscover/autodiscover.xml"

#>

[CmdletBinding()]
Param (
  [parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [string] $wafPolicyName,
  [parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [string] $resourceGroupName,
  [parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [string] $appGWName,
  [parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [string] $customRuleName,
  [parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [string] $customRulePriority,
  [parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [string] $keywordToBlock
)

try {
  $appGW = Get-AzApplicationGateway -Name $appGWName -ResourceGroupName $resourceGroupName

  # Match the existing WAF managed rule Setting and create WAF Policy based on that
  if ($appGW.WebApplicationFirewallConfiguration) {
    $ruleGroupOverrides = [System.Collections.ArrayList]@()
    # check if there are any disabled manage rules in existing WAF settings
    if ($appGW.WebApplicationFirewallConfiguration.DisabledRuleGroups) {

      # Incorportate disabled rules which are part of our current WAF Configuration
      foreach ($disabled in $appGW.WebApplicationFirewallConfiguration.DisabledRuleGroups) {
        $rules = [System.Collections.ArrayList]@()
        if ($disabled.Rules.Count -gt 0) {
          foreach ($rule in $disabled.Rules) {
            $ruleOverride = New-AzApplicationGatewayFirewallPolicyManagedRuleOverride -RuleId $rule
            $_ = $rules.Add($ruleOverride)
          }
        }

        $ruleGroupOverride = New-AzApplicationGatewayFirewallPolicyManagedRuleGroupOverride `
          -RuleGroupName $disabled.RuleGroupName -Rule $rules
        $_ = $ruleGroupOverrides.Add($ruleGroupOverride)
      }
    }

    # Add managed rule set based on the existing WAF Configuration
    if ($ruleGroupOverrides.Count -ne 0) {
      $managedRuleSet = New-AzApplicationGatewayFirewallPolicyManagedRuleSet -RuleSetType $appGW.WebApplicationFirewallConfiguration.RuleSetType -RuleSetVersion $appGW.WebApplicationFirewallConfiguration.RuleSetVersion -RuleGroupOverride $ruleGroupOverrides
    }
    else {
      $managedRuleSet = New-AzApplicationGatewayFirewallPolicyManagedRuleSet -RuleSetType $appGW.WebApplicationFirewallConfiguration.RuleSetType -RuleSetVersion $appGW.WebApplicationFirewallConfiguration.RuleSetVersion
    }

    # Create Managed Rule using the managed rule set
    $managedRule = New-AzApplicationGatewayFirewallPolicyManagedRule `
      -ManagedRuleSet $managedRuleSet


    # Create WAF Policy Setting using the current application gateway firewall setting
    $policySetting = New-AzApplicationGatewayFirewallPolicySetting `
      -MaxFileUploadInMb $appGW.WebApplicationFirewallConfiguration.FileUploadLimitInMb `
      -MaxRequestBodySizeInKb $appGW.WebApplicationFirewallConfiguration.MaxRequestBodySizeInKb `
      -Mode $appGW.WebApplicationFirewallConfiguration.FirewallMode -State Disabled

    if ($appGW.WebApplicationFirewallConfiguration.Enabled) {
      $policySetting.State = "Enabled"
    }

    $policySetting.RequestBodyCheck = $appGW.WebApplicationFirewallConfiguration.RequestBodyCheck
  }

  # Create WAF Policy by using the policy setting and managed rule set defined above

  New-AzApplicationGatewayFirewallPolicy `
    -Name $wafPolicyName -ResourceGroupName $resourceGroupName `
    -PolicySetting $policySetting -ManagedRule `
    $managedRule -Location $appGW.Location | Out-Null


  #create custom rule variable
  $requestVariable = New-AzApplicationGatewayFirewallMatchVariable -VariableName RequestUri

  # check in request uri if keyword is present or not
  # if present block the access
  $requestCondition = New-AzApplicationGatewayFirewallCondition -MatchVariable `
    $requestVariable -Operator Contains -MatchValue $keywordToBlock `
    -NegationCondition $false

  # Create Custom Rule
  $azRule = New-AzApplicationGatewayFirewallCustomRule -Name $customRuleName `
    -Priority $customRulePriority -RuleType MatchRule -MatchCondition `
    $requestCondition -Action Block

  # check if Application Firewall Policy is created or not
  $policy = Get-AzApplicationGatewayFirewallPolicy `
    -Name $wafPolicyName -ResourceGroupName $resourceGroupName


  # if policy is present, apply the custom rule
  if ($policy) {

    Write-Host "Windows Application Firewall Policy is deployed: $($policy.Name)"

    # set WAF Policy based on custom rule
    Set-AzApplicationGatewayFirewallPolicy -Name $wafPolicyName `
      -ResourceGroupName $resourceGroupName -CustomRule $azRule

    # add application gateway firewall policy to the Application Gateway
    # Comment below two lines if you want to deploy only WAF Policy Resource without applying it to the Application Gateway
    $appGW.FirewallPolicy = $policy
    $appGW = Set-AzApplicationGateway -ApplicationGateway $appGW

    if ($appGW.FirewallPolicy) {
      Write-Host "WAF Policy is present and is connected to Application Gateway: $($appGW.Name)"
    }
    else {
      Write-Host "WAF Policy is present but is not connected to the Application Gateway"
    }
  }
  else {
    Write-Host "Windows Application Firewall Policy is not present"
  }
}
catch {
  Write-Error -Message ("Exception Occurred while deploying WAF Policy " + ": $($_.Exception)")
}
