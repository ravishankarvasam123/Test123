
Import-Module Az.Accounts
Import-Module Az.Resources
Connect-AzAccount  -Subscription "BHDBTNonProduction"
$path = "C:\DBTSitecorePlatform\infra\topology\"
$saContext = Get-AzStorageAccount -Name "bhdbtsbxscdevops" -ResourceGroupName "bh-dbt-sbx-sitecore-admin-rg" -ErrorAction Stop

Push-Location $path   
Get-ChildItem -File -Recurse | Set-AzStorageBlobContent -Container "template" -Context $saContext.Context -Force
Pop-Location