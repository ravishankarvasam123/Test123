<#
.SYNOPSIS
Create a no db wsp package for wdp.the package are referred from the artifacts,
created during the runtime.
To include a new package mapped the name and filename mapped in the cloud-9.2.0-xp1\assets.json
.PARAMETER ConfigurationFilePath
package File Name

#>
[CmdletBinding(SupportsShouldProcess=$true)]
Param(
  [Parameter(Mandatory=$true)]
  [string] $ConfigurationFilePath = $(join-path (Split-Path -parent $PSScriptRoot) "\configuration\sbx\install.json")
)

Function ScwdpNoSql {
  param(
   
    [string] $ConfigurationFilePath
  )

    #Import ProcessConfigFile function
    Import-Module $PSScriptRoot\modules\saf\saf.psd1 -Force
    $configArray = ProcessConfigFile -Config $ConfigurationFilePath
    $config = $configArray[0]

    $assetsFolder = (Join-Path $config.DeployFolder "assets")

    #set the wdp path
    $PackagePath = (Join-Path $assetsFolder "Sitecore Experience Platform")

    #Import Azure Toolkit
    Import-Module "$assetsFolder/Sitecore Azure Toolkit/tools/Sitecore.Cloud.Cmdlets.psm1"
    Import-Module "$assetsFolder/Sitecore Azure Toolkit/tools/Sitecore.Cloud.CmdLets.dll"

    $scwdpNames = @{
        "cd" ="Sitecore 9.2.0 rev. 002893 (Cloud)_cd.scwdp.zip";
        "cm" ="Sitecore 9.2.0 rev. 002893 (Cloud)_cm.scwdp.zip";
        "prc" ="Sitecore 9.2.0 rev. 002893 (Cloud)_prc.scwdp.zip";
        "rep" = "Sitecore 9.2.0 rev. 002893 (Cloud)_rep.scwdp.zip";        
        #"xcCollect" = "Sitecore 9.2.0 rev. 002893 (Cloud)_xp1collection.scwdp.zip";
      }

      $scwdpNames.GetEnumerator()|ForEach-Object {

      #Check if the names are 
       if(($_.Name -eq 'cd') -Or ($_.Name -eq 'cm') -Or ($_.Name -eq 'prc') -Or ($_.Name -eq 'rep'))# -Or ($_.Name -eq 'xcCollect'))
       {
         
          $scwdp = Join-Path $PackagePath $_.Value
          Write-Verbose ("create no db wdp for - {0}" -F $scwdp)
          Remove-SCDatabaseOperations `
                -Path "$scwdp" `
                -Destination $PackagePath `
                -Verbose `
                -Force
         
       }
       else
       {
         
         #Set the path base on the name and value of the array
         $wdpPath = Join-Path $assetsFolder $_.Name
         $scwdp = Join-Path $wdpPath $_.Value
         Write-Verbose ("create no db wdp for - {0}" -F $scwdp)
          Remove-SCDatabaseOperations `
                -Path "$scwdp" `
                -Destination $wdpPath `
                -Verbose `
                -Force
        
         
       }
        Write-Verbose ("{0} - without db scwdp created successfully" -F $_.Value)
      }

}

#Generate the no-sql version of the scwdp
ScwdpNoSql -ConfigurationFilePath $ConfigurationFilePath
write-Verbose "sitecore web deploy package - no sql version created successfully"

