<#
.SYNOPSIS
 Copy Azure Sql Database from Source Sql Server to Target Sql Server.
 Once Database Copy Created Successfully In Target Sql Server Then Export Database Copy To Storage Account As A .bacpac file. 

.PARAMETER SourceResourceGroupName
Resource group of source sql server/database

.PARAMETER SourceSqlServerName
Source sql server where database present that needs to be backup/exported to storage account.

.PARAMETER TargetResourceGroupName
Resource group of target sql server.

.PARAMETER TargetSqlServerName
Target sql server where database copy should be get created

.PARAMETER KeyVaultName
KeyVault Name where target sql server login & password secrets are present.

.PARAMETER TargetSqlServerAdministratorLoginKeySecret
Secret of target sql server admin login

.PARAMETER TargetSqlServerAdministratorPasswordKeySecret
Secret of target sql server admin login password

.PARAMETER StorageKey
Access key of storage account  where database copy should be export to as .bacpac file.

.PARAMETER StorageUri
Storage account container path where database copy should be export to as .bacpac file.

.PARAMETER CopiedDatabaseNameSuffix
Suffix for database copy name.

.PARAMETER AzureSqlDatabaseNamesToBackup
Specify comma seperated database names that needs to be backup/exported to storage account.


#>
[CmdletBinding()]
Param(
  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [String] $SubscriptionName,  
  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [String] $SourceResourceGroupName,
  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [String] $SourceSqlServerName,
  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [String] $TargetResourceGroupName,
  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [String] $TargetSqlServerName,
  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [String] $KeyVaultName,
  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [String] $TargetSqlServerAdministratorLoginKeySecret,
  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [String] $TargetSqlServerAdministratorPasswordKeySecret,
  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [String] $StorageKey,
  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [String] $StorageUri,
  [Parameter(Mandatory = $false)]
  [string] $CopiedDatabaseNameSuffix ="copy",
  [Parameter(Mandatory = $true)]
  [string[]] $AzureSqlDatabaseNamesToBackup = @()
)


# Az Module Version - Tested Script with Az module version 3.3.0 & Az.Sql 2.1.2


<# - Script parameters for SBX
-SubscriptionName "BHDBTNonProduction"
-TargetResourceGroupName "bh-dbt-sbx-sitecore-platform-rg"
-TargetSqlServerName "bh-dbt-sbx-sc-sql"
-SourceResourceGroupName "bh-dbt-sbx-sitecore-platform-rg"
-SourceSqlServerName "bh-dbt-sbx-sc-sql"
-KeyVaultName "bh-dbt-nonprod-sc-kv"
-TargetSqlServerAdministratorLoginKeySecret "sbx-sql-server-login"
-TargetSqlServerAdministratorPasswordKeySecret "sbx-sql-server-password"
-StorageKey "/yy/l1Pdbg0vHlZpzJb7Qb5MjRrikc0LnHnUMbuVHCuCvP/L89/Akp5iISh7524ozA5kL/MGEoZ5DdwVpeyYiQ=="
-StorageUri "https://bhdbtnonprdscdev.blob.core.windows.net/dbbackup/"
-AzureSqlDatabaseNames "bh-dbt-sbx-sc-master-db","bh-dbt-sbx-sc-sessions-db"
#>

<# - Script parameters for PROD
-SubscriptionName "BHDBTProduction"
-TargetResourceGroupName "bh-dbt-prd-sitecore-platform-rg"
-TargetSqlServerName "bh-dbt-prd-sc-sql"
-SourceResourceGroupName "bh-dbt-prd-sitecore-platform-rg"
-SourceSqlServerName "bh-dbt-prd-sc-sql"
-KeyVaultName "bh-dbt-prd-sc-kv"
-TargetSqlServerAdministratorLoginKeySecret "prod-sql-server-login"
-TargetSqlServerAdministratorPasswordKeySecret "prod-sql-server-password"
-StorageKey "7WL+3FhKpOKTk9LpM+vm2tlMvpHfD+YDHFfYdfIDgtXTTXqU1iljLvIn1s1NsOiYWwV+JG4NInJBGTJW5ehT+Q=="
-StorageUri "https://bhdbtprdscdevopsasa.blob.core.windows.net/dbbackups/"
-AzureSqlDatabaseNames "bh-dbt-prd-sc-master-db","bh-dbt-prd-sc-sessions-db"
#>


[System.Collections.Generic.List[object]] $AzSqlDatabasesToBackup = @() 
[System.Collections.Generic.List[string]] $AzSqlDatabaseCopyNames = @() 
$AzSqlDatabaseExportRequests = @{}

$azContext = Get-AzContext

if($null -eq $azContext) {

  ## Connect to Azure
  Connect-AzAccount  
  Set-AzContext -Subscription $SubscriptionName
  $azContext = Get-AzContext  
}
else {

  if($null -ne $SubscriptionName -and $SubscriptionName -ne $azContext.Subscription.Name) {
    throw "subscription provided $SubscriptionName does not match context subscription $($azContext.Subscription.Name).Disconnect current az account using command 'Disconnect-AzAccount' & try again. "
  }
}

## Validate specified source resource group exist or not.
$SourceResourceGroup = Get-AzResourceGroup -Name $SourceResourceGroupName -ErrorAction SilentlyContinue
if($sourceResourceGroup -eq $null){

Write-Host "Source Resource Group '"$SourceResourceGroupName"' does not exist.Terminating execution ..." -foregroundcolor Red
return

}else{
     Write-Host "Source Resource Group '"$SourceResourceGroupName"' exist" -foregroundcolor White
}

## Validate specified source sql server exist or not.
$SourceSqlServer = Get-AzSqlServer -Name $SourceSqlServerName -ResourceGroupName $SourceResourceGroupName -ErrorAction SilentlyContinue

if($SourceSqlServer -eq $null){

Write-Host "Source Sql Server '"$SourceSqlServerName"' does not exist.Terminating execution ..." -foregroundcolor Red
return

}else{
     Write-Host "Source Sql Server '"$SourceSqlServerName"' exist" -foregroundcolor White
}


## Validate specified target resource group exist or not.
$TargetResourceGroup = Get-AzResourceGroup -Name $TargetResourceGroupName -ErrorAction SilentlyContinue
if($TargetResourceGroup  -eq $null){

Write-Host "Target Resource Group '"$TargetResourceGroupName"' does not exist.Terminating execution ..." -foregroundcolor Red
return

}else{
     Write-Host "Target Resource Group '"$TargetResourceGroupName"' exist" -foregroundcolor White
}

## Validate specified target sql server exist or not.
$TargetSqlServer = Get-AzSqlServer -Name $TargetSqlServerName -ResourceGroupName $TargetResourceGroupName -ErrorAction SilentlyContinue
                                                                      
if($TargetSqlServer -eq $null){

Write-Host "Target Sql Server '"$TargetSqlServerName"' does not exist.Terminating execution ..." -foregroundcolor Red
return

}else{
     Write-Host "Target Sql Server '"$TargetSqlServerName"' exist" -foregroundcolor White
}


if($AzureSqlDatabaseNamesToBackup.Count -gt 0) {

## Validate specified databases (whose backup needs to be taken) exist or not.
$AzureSqlDatabaseNamesToBackup | ForEach-Object {

$AzSqlDatabase = $null
$AzSqlDatabase = Get-AzSqlDatabase -ResourceGroupName $SourceResourceGroupName -ServerName $SourceSqlServerName  -DatabaseName $_ -ErrorAction SilentlyContinue
                                                                                                       
if($AzSqlDatabase -ne $null) {

$AzSqlDatabasesToBackup.Add($AzSqlDatabase)

}else{

Write-Host "Database '"$_"' does not exist for backup. Skipping this database ...." -foregroundcolor Red

}}

"`n"
## Step 1 :- Database Copy Operation
$AzSqlDatabasesToBackup | ForEach-Object {

$currentDate = Get-Date -Format "yyyy-MM-dd-HH-mm"
$DatabaseCopyName = [System.String]::Concat($_.DatabaseName,"-", $CopiedDatabaseNameSuffix,"-",$currentDate)

 $Database = $null
 $Database = Get-AzSqlDatabase -ResourceGroupName $TargetResourceGroupName -ServerName $TargetSqlServerName  -DatabaseName $DatabaseCopyName -ErrorAction SilentlyContinue

 if($Database -eq $null){

  Write-Host "Database copy operation is in progress for database '"$_.DatabaseName"'"  -foregroundcolor White
  $AzSqlDatabaseCopy = $null
  $AzSqlDatabaseCopy = New-AzSqlDatabaseCopy -AsJob -CopyResourceGroupName $TargetResourceGroupName -CopyServerName $TargetSqlServerName -CopyDatabaseName $DatabaseCopyName -ResourceGroupName  $SourceResourceGroupName -ServerName $SourceSqlServerName -DatabaseName $_.DatabaseName

  if($AzSqlDatabaseCopy -ne $nulll){
  $AzSqlDatabaseCopyNames.Add($DatabaseCopyName) } 

 }else{

 ## Remove existing database copy before creating new copy.
  Remove-AzSqlDatabase -DatabaseName $DatabaseCopyName  -ResourceGroupName $TargetResourceGroupName -ServerName $TargetSqlServerName -Force | Out-Null
  Start-Sleep -s 20

  $ExistingDatabaseCopy = $null
  $ExistingDatabaseCopy = Get-AzSqlDatabase -ResourceGroupName $TargetResourceGroupName -ServerName $TargetSqlServerName  -DatabaseName $DatabaseCopyName -ErrorAction SilentlyContinue

  ## Make sure existing database copy removed successfully or not.
  while($ExistingDatabaseCopy -ne $null){
  Start-Sleep -s 5
  $ExistingDatabaseCopy = Get-AzSqlDatabase -ResourceGroupName $TargetResourceGroupName -ServerName $TargetSqlServerName  -DatabaseName $DatabaseCopyName -ErrorAction SilentlyContinue

  }
  
  Write-Host "Database copy operation is in progress for database '"$_.DatabaseName"'"  -foregroundcolor White
  $AzSqlDatabaseCopy = $null
  $AzSqlDatabaseCopy = New-AzSqlDatabaseCopy -AsJob -CopyResourceGroupName $TargetResourceGroupName -CopyServerName $TargetSqlServerName -CopyDatabaseName $DatabaseCopyName -ResourceGroupName  $SourceResourceGroupName -ServerName $SourceSqlServerName -DatabaseName $_.DatabaseName

  if($AzSqlDatabaseCopy -ne $nulll){
  $AzSqlDatabaseCopyNames.Add($DatabaseCopyName) }

 }}

 
# Pull for finished jobs
  Get-Job | Wait-Job | Out-Null
  
"`n"
## Step 2 : Database Export Operation

Import-Module -Name "Az.KeyVault"


## Get Sql Login Secret
$sqlServerAdminLoginSecret = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name $TargetSqlServerAdministratorLoginKeySecret -ErrorAction SilentlyContinue

if($sqlServerAdminLoginSecret -ne $null){
$sqlServerAdminLogin = ConvertFrom-SecureString -SecureString $sqlServerAdminLoginSecret.SecretValue -AsPlainText

$sqlServerAdminLogin

}else{

  Write-Host "Retrieving key valut secret '"TargetSqlServerAdministratorLoginKeySecret"'failed.Terminating execution ..."  -foregroundcolor Red

  return
}


## Get SQL Login Password Secret
$sqlServerAdminPasswordSecret = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name $TargetSqlServerAdministratorPasswordKeySecret -ErrorAction SilentlyContinue

if($sqlServerAdminPasswordSecret  -ne $null){

$secureSqlServerAdminPassword = $sqlServerAdminPasswordSecret.SecretValue
}else{

Write-Host "Retrieving key valut secret '"$TargetSqlServerAdministratorPasswordKeySecret"'failed. Terminating execution ..."  -foregroundcolor Red
return
}



## Database Export Operation
$AzSqlDatabaseCopyNames | ForEach-Object {

 $DatabaseToExport = $null
 $DatabaseToExport = Get-AzSqlDatabase -ResourceGroupName $TargetResourceGroupName -ServerName $TargetSqlServerName -DatabaseName $_ -ErrorAction SilentlyContinue
 $DBNameIndex = $_.LastIndexOf([System.String]::Concat('-',$CopiedDatabaseNameSuffix))
 $DBName = $_.Substring(0,$DBNameIndex)

 if($DatabaseToExport -ne $null){

    Write-Host "Database copy operation completed for database '"$DBName"'. Database copy name is '"$_"'" -foregroundcolor Green
    $AzureStorageAccountUri = ""    
    $AzureStorageAccountUri = [System.String]::Concat($StorageUri, $_,".bacpac") 

    $exportRequest = $null
    $exportRequest = New-AzSqlDatabaseExport -ResourceGroupName $TargetResourceGroupName -ServerName $TargetSqlServerName -DatabaseName $_ -StorageKeyType "StorageAccessKey" -StorageKey $StorageKey -StorageUri $AzureStorageAccountUri -AdministratorLogin $sqlServerAdminLogin  -AdministratorLoginPassword $secureSqlServerAdminPassword   -AuthenticationType "Sql" -ErrorAction SilentlyContinue   

    if($exportRequest -ne $null){
    $AzSqlDatabaseExportRequests.Add($_, $exportRequest)}else{

       Write-Host "Database export operation failed for database '"$DBName"'" -foregroundcolor Red
    }
         
 }else{

 Write-Host "Database copy/export operation failed for database '"$DBName"'" -foregroundcolor Red

 }}

 "`n"
 $AzSqlDatabaseExportRequests.Keys | ForEach-Object {

 Write-Host "Database export operation is in progress for database '"$_"'"  -foregroundcolor White
 $exportStatus = $null
 $exportStatus = Get-AzSqlDatabaseImportExportStatus -OperationStatusLink  ($AzSqlDatabaseExportRequests[$_]).OperationStatusLink

 ## Check database export operation status in every 15 seconds untill it gets failed/succeeded
 while ($exportStatus.Status -eq "InProgress")
 {

 Start-Sleep -s 15
 $exportStatus = Get-AzSqlDatabaseImportExportStatus -OperationStatusLink ($AzSqlDatabaseExportRequests[$_]).OperationStatusLink

 }

 if($exportStatus.Status -eq "Failed"){

 Write-Host "Database export operation failed for database '"$_"'" -foregroundcolor Red
 "`n"
 }
 elseif($exportStatus.Status -eq "Succeeded") {

 Write-Host "Database export operation completed successfully for database '"$_"'" -foregroundcolor Green

 ## Remove copied database from target sql server after database exported successfully in storage account.
  Remove-AzSqlDatabase -DatabaseName $_  -ResourceGroupName $TargetResourceGroupName -ServerName $TargetSqlServerName -Force | Out-Null
  Start-Sleep -s 20

  $DatabaseCopy = $null
  $DatabaseCopy = Get-AzSqlDatabase -ResourceGroupName $TargetResourceGroupName -ServerName $TargetSqlServerName  -DatabaseName $_ -ErrorAction SilentlyContinue

  ## Make sure existing database copy removed successfully or not.
  while($DatabaseCopy -ne $null){
  Start-Sleep -s 5
  $DatabaseCopy = Get-AzSqlDatabase -ResourceGroupName $TargetResourceGroupName -ServerName $TargetSqlServerName  -DatabaseName $_ -ErrorAction SilentlyContinue

  }

  Write-Host "Database copy '"$_"' deleted successfully." -foregroundcolor Green
  "`n"
 }}

 }

  Write-Host "Script Completed." -foregroundcolor Green
  